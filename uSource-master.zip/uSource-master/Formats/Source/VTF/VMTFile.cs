﻿
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.HighDefinition;



namespace uSource.Formats.Source.VTF
{
    public class VMTFile
    {
        public string FileName = "";
        public VMTFile Include;
        public string ShaderType;
        public string SurfaceProp;
        public Material Material;
        public Material DefaultMaterial;
        public static int TransparentQueue = 3001;
        private string sourceSkyboxPath = @"D:\STEAM\steamapps\common\Black Mesa\bms\materials\skybox\";

        #region KeyValues
        public KeyValues.Entry this[string shader] => KeyValues[shader];
        public KeyValues KeyValues;

        public bool ContainsParam(string param) => this[ShaderType].ContainsKey(param);
        public string GetParam(string param) => this[ShaderType][param];
        public float GetSingle(string param) => GetParam(param).ToSingle();

        // Define a regex pattern for parsing float values from strings
        private static readonly Regex FloatRegex = new Regex(@"[+-]?([0-9]*[.])?[0-9]+");

        public Vector4 GetVector4(string param, bool swap = false)
        {
            var matches = FloatRegex.Matches(GetParam(param));
            float x = matches.Count >= 1 ? float.Parse(matches[0].Value) : 0;
            float y = matches.Count >= 2 ? float.Parse(matches[1].Value) : (swap ? x : 0);
            float z = matches.Count >= 3 ? float.Parse(matches[2].Value) : (swap ? y : 0);
            float w = matches.Count >= 4 ? float.Parse(matches[3].Value) : (swap ? z : 0);
            return new Vector4(x, y, z, w);
        }

        public Vector3 GetVector3(string param, bool swap = false)
        {
            var vector4 = GetVector4(param, swap);
            return new Vector3(vector4.x, vector4.y, vector4.z);
        }

        public Vector2 GetVector2(string param, bool swap = false)
        {
            var vector4 = GetVector4(param, swap);
            return new Vector2(vector4.x, vector4.y);
        }

        public int GetInteger(string param) => int.TryParse(GetParam(param), out int result) ? result : 0;

        public Color32 GetColor()
        {
            Color color = new Color32(255, 255, 255, 255);
            if (ContainsParam("$color"))
                color = ColorUtility.TryParseHtmlString(this[ShaderType]["$color"], out color) ? color : color;
            if (ContainsParam("$alpha"))
                color.a = (byte)(255 * float.Parse(this[ShaderType]["$alpha"]));
            return color;
        }

        public bool IsTrue(string input, bool containsCheck = true)
        {
            return containsCheck && ContainsParam(input) && this[ShaderType][input] == "1";
        }
        #endregion

        public bool HasAnimation = false;
        public void SetupAnimations(ref AnimatedTexture controlScript) { /* Implementation */ }

        void MakeDefaultMaterial() { /* Implementation */ }

        public VMTFile(Stream stream, string fileName = "")
        {
            this.FileName = fileName;
            if (stream == null) { MakeDefaultMaterial(); return; }
            KeyValues = KeyValues.FromStream(stream);
            ShaderType = KeyValues.Keys.First();
        }

        public void CreateMaterial()
        {
            #region Patch "Shader"
            if (ContainsParam("replace"))
                this[ShaderType].MergeFrom(this[ShaderType]["replace"], true);

            if (ContainsParam("include"))
            {
                Include = uResourceManager.LoadMaterial(GetParam("include"));
                this[ShaderType].MergeFrom(Include[Include.ShaderType], false);
            }

            if (ContainsParam("insert"))
                this[ShaderType].MergeFrom(this[ShaderType]["insert"], false);
            #endregion

            if (ContainsParam("$fallbackmaterial"))
            {
                Include = uResourceManager.LoadMaterial(GetParam("$fallbackmaterial"));
                this[ShaderType].MergeFrom(Include[Include.ShaderType], true);
            }

#if UNITY_EDITOR
            if (uLoader.SaveAssetsToUnity)
            {
                Material = uResourceManager.LoadAsset<Material>(FileName, uResourceManager.MaterialsExtension[0], ".mat");
                if (Material != null)
                    return;
            }
#endif

            // Base texture and alpha detection
            String textureName;
            String propertyName;
            Texture2D baseTexture = null;
            Boolean hasAlpha = false;

            if (ContainsParam("$basetexture") || ContainsParam("$envmapmask"))
            {
                textureName = GetParam("$basetexture");
                if (string.IsNullOrEmpty(textureName))
                    textureName = GetParam("$envmapmask");

                baseTexture = uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, "_MainTex" } })[0, 0];

#if UNITY_EDITOR
                if (baseTexture != null)
                    hasAlpha = baseTexture.alphaIsTransparency;
#endif
            }

            Material = new Material(GetShader(Include == null ? ShaderType : Include.ShaderType, hasAlpha));
            Material.name = FileName;
            Material.color = GetColor();
            bool isHDRP = GraphicsSettings.currentRenderPipeline is HDRenderPipelineAsset;
            if (baseTexture != null)
                Material.mainTexture = baseTexture;

            // Support for secondary base texture
            if (ContainsParam("$basetexture2"))
            {
                textureName = GetParam("$basetexture2");
                propertyName = "_SecondTex";
                if (Material.HasProperty(propertyName))
                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
            }

            string normalMapProperty = GraphicsSettings.currentRenderPipeline is HDRenderPipelineAsset ? "_NormalMap" : "_BumpMap";
            // Normal map support for HDRP
            if (ContainsParam("$bumpmap"))
            {
                string normalMapName = GetParam("$bumpmap");
                Texture2D normalMap = LoadTexture(normalMapName);

                if (normalMap != null && Material.HasProperty(normalMapProperty))
                {
                    // Convert to normal map format if needed
                    Texture2D processedNormalMap = ProcessAsNormalMap(normalMap);
                    Material.SetTexture(normalMapProperty, processedNormalMap);

                    // Enable normal map keyword
                    Material.EnableKeyword("_NORMALMAP");
                }
            }

            if (ContainsParam("$bumpmap2"))
            {
                string secondaryNormalMapName = GetParam("$bumpmap2");
                Texture2D secondaryNormalMap = LoadTexture(secondaryNormalMapName);

                if (secondaryNormalMap != null && Material.HasProperty(normalMapProperty + "2"))
                {
                    Texture2D processedSecondaryNormalMap = ProcessAsNormalMap(secondaryNormalMap);
                    Material.SetTexture(normalMapProperty + "2", processedSecondaryNormalMap);

                    Material.EnableKeyword("_NORMALMAP2");
                }
            }

            // SSBump map support
            // SSBump map handling
            if (ContainsParam("$ssbump"))
            {
                string ssbumpMapName = GetParam("$ssbump");
                Texture2D ssbumpMap = LoadTexture(ssbumpMapName);

                if (ssbumpMap != null && Material.HasProperty(normalMapProperty))
                {
                    Texture2D processedSSBumpMap = ProcessAsSSBumpMap(ssbumpMap);
                    Material.SetTexture(normalMapProperty, processedSSBumpMap);

                    Material.EnableKeyword("_NORMALMAP");
                }
            }


         

            // Configure transparency and culling settings
            if (IsTrue("$translucent"))
                Material.renderQueue = TransparentQueue++;

            if (IsTrue("$alphatest"))
                Material.renderQueue = (int)UnityEngine.Rendering.RenderQueue.AlphaTest;

            if (IsTrue("$nocull"))
            {
                if (Material.HasProperty("_Cull"))
                    Material.SetInt("_Cull", 0);
            }

            // Detail texture blending
            if (ContainsParam("$detail"))
            {
                propertyName = "_Detail";
                if (Material.HasProperty(propertyName))
                {
                    textureName = GetParam("$detail");
                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);

                    if (ContainsParam("$detailscale"))
                        Material.SetTextureScale("_Detail", GetVector2("$detailscale", true));

                    if (Material.HasProperty("_DetailFactor"))
                    {
                        Material.SetFloat("_DetailFactor", ContainsParam("$detailblendfactor") ? GetSingle("$detailblendfactor") / 2 : 0.5f);

                        if (ContainsParam("$detailblendmode"))
                            Material.SetInt("_DetailBlendMode", GetInteger("$detailblendmode"));
                    }
                }
            }
            if (ContainsParam("$envmapmask"))
            {

                textureName = GetParam("$envmapmask");
                propertyName = "_EnvMapMask";

                if (Material.HasProperty(propertyName))
                {
                    if (ContainsParam("$envmapmaskscale"))

                        Material.SetTextureScale("_EnvMapMask", GetVector2("$envmapmaskscale", true));
                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);



                    Material.EnableKeyword("_ENVMAPMASK");

                }
            }
            if (ContainsParam("$envmap"))
            {
                textureName = GetParam("$envmap");
                propertyName = "_Reflection";
                if (Material.HasProperty(propertyName))
                {

                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                    Material.EnableKeyword("_REFLECTION");

                }

            }


            if (IsTrue("$translucent")) Material.renderQueue = TransparentQueue++;

            if (IsTrue("$alphatest")) Material.renderQueue = (int)UnityEngine.Rendering.RenderQueue.AlphaTest;
            if (IsTrue("$additive")) Material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);

            if (ContainsParam("$phong")) Material.EnableKeyword("_PHONG");
            {
                textureName = GetParam("$phong");
                propertyName = "_Phong";
                if (Material.HasProperty(propertyName))
                {

                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                    Material.EnableKeyword("_PHONG");
                }
            }
            if (ContainsParam("$rimlight")) Material.EnableKeyword("_RIM_LIGHTING");
            {
                textureName = GetParam("$rimlight");
                propertyName = "_RimLight";

                if (Material.HasProperty(propertyName))
                {

                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                    Material.EnableKeyword("_RIM_LIGHTING");

                }
            }


            if (ContainsParam("$lightwarptexture"))
            {
                textureName = GetParam("$lightwarptexture");

                propertyName = "_LightWarp";

                if (Material.HasProperty(propertyName))
                {
                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                    Material.EnableKeyword("_LIGHTWARP");
                }

            }
            // Normal, bump, and SSBump maps


            // Parallax map for added depth
            if (ContainsParam("$parallaxmap")) Material.SetTexture("_ParallaxMap", LoadTexture(GetParam("$parallaxmap")));
            {


                textureName = GetParam("$parallaxmap");
                propertyName = "_ParallaxMap";

                if (Material.HasProperty(propertyName))
                {

                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                    Material.EnableKeyword("_PARALLAX_MAP");
                }

            }
            // Self-illumination or emissive
            if (IsTrue("$selfillum"))
            {
                textureName = GetParam("$selfillum");
                propertyName = "_Emission";
                if (Material.HasProperty(propertyName))
                {

                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                    Material.EnableKeyword("_EMISSION");
                }

            }

            // Surface properties for physical interactions (e.g., sound)
            if (ContainsParam("$surfaceprop"))
            {
                textureName = GetParam("$surfaceprop");
                propertyName = "_SurfaceProp";
                if (Material.HasProperty(propertyName))
                {
                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                    Material.EnableKeyword("_SURFACEPROP");
                }

            }
            if (ContainsParam("$halflambert"))
            {
                textureName = GetParam("$halflambert");
                propertyName = "_HalfLambert";


                if (Material.HasProperty(propertyName))
                {
                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                    Material.EnableKeyword("_HALFLAMBERT");
                }

            }



            if (ContainsParam("$burning"))
            {

                textureName = GetParam("$burning");
                propertyName = "_Burning";

                if (Material.HasProperty(propertyName))
                {
                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                    Material.EnableKeyword("_BURNING");
                }


            }

            if (ContainsParam("$flesh"))
            {
                textureName = GetParam("$flesh");
                propertyName = "_Flesh";


                if (Material.HasProperty("$flesh"))
                {

                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                    Material.EnableKeyword("_FLESH");
                }



                if (ContainsParam("$frame"))
                {

                    textureName = GetParam("$frame");
                    propertyName = "_Frame";

                    if (Material.HasProperty(propertyName))
                    {
                        Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                        Material.EnableKeyword("_FRAME");
                    }


                    if (ContainsParam("$decal"))
                    {
                        textureName = GetParam("$decal");
                        propertyName = "_Decal";

                        if (Material.HasProperty(propertyName))
                        {

                            if (ContainsParam("$decalscale"))

                                Material.SetTextureScale("_Decal", GetVector2("$decalscale", true));
                            Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                            Material.EnableKeyword("_DECAL");
                        }

                        if (ContainsParam("$decaltexture"))
                        {
                            textureName = GetParam("$decaltexture");
                            propertyName = "_DecalTexture";

                            if (Material.HasProperty(propertyName))
                            {
                                if (ContainsParam("$decalscale"))

                                    Material.SetTextureScale("_Decal", GetVector2("$decalscale", true));
                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                Material.EnableKeyword("_DECALTEXTURE");
                            }

                        }

                        if (ContainsParam("$color"))
                        {


                            Material.color = GetColor();

                            textureName = GetParam("$color");
                            propertyName = "_Color";

                            if (Material.HasProperty(propertyName))
                            {
                                Material.SetColor(propertyName, GetColor());

                                Material.EnableKeyword("_COLOR");


                            }


                            if (ContainsParam("$metalness"))
                            {


                                textureName = GetParam("$metalness");
                                propertyName = "_Metalness";

                                if (Material.HasProperty(propertyName))
                                {
                                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                    Material.EnableKeyword("_METALNESS");
                                }
                            }


                            if (ContainsParam("$mask1"))
                            {

                                textureName = GetParam("$mask1");
                                propertyName = "_Mask1";

                                if (Material.HasProperty(propertyName))
                                {
                                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                    Material.EnableKeyword("_MASK_1");
                                }


                                if (ContainsParam("$mask2"))
                                {
                                    textureName = GetParam("$mask2");
                                    propertyName = "_Mask2";

                                    if (Material.HasProperty(propertyName))
                                    {
                                        Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                        Material.EnableKeyword("_MASK_2");
                                    }
                                }

                                if (ContainsParam("$maskstexture"))
                                {
                                    textureName = GetParam("$maskstexture");
                                    propertyName = "_MasksTexture";

                                    if (Material.HasProperty(propertyName))
                                    {
                                        Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                        Material.EnableKeyword("_MASKS_TEXTURE");
                                    }
                                }


                                if (ContainsParam("$fresnelreflection"))
                                {
                                    textureName = GetParam("_FresnelReflection");
                                    propertyName = "_FresnelReflection";


                                    if (ContainsParam(propertyName))
                                        if (ContainsParam("$envmaplightscale"))

                                            Material.SetTextureScale("_EnvMapLightScale", GetVector2("$envmaplightscale", true));
                                    Material.SetTexture(textureName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);

                                    Material.EnableKeyword("_FRESNEL_REFLECTION");
                                }
                                if (ContainsParam("$reflectivity"))

                                {

                                    textureName = GetParam("$reflectivity");
                                    propertyName = "_Reflectivity";

                                    if (Material.HasProperty(propertyName))
                                    {
                                        Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                        Material.EnableKeyword("_REFLECTIVITY");
                                    }



                                }



                                if (ContainsParam("$fresnelrangestexture"))
                                {
                                    textureName = GetParam("$fresnelrangestexture");
                                    propertyName = "_FrenselRangesTexture";


                                    if (Material.HasProperty(propertyName))
                                    {

                                        Material.SetTexture(textureName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                        Material.EnableKeyword("_FRESNEL_RANGES_TEXTURE");




                                    }
                                    if (ContainsParam("$translucent"))
                                    {

                                        textureName = GetParam("$translucent");
                                        propertyName = "_Translucent";


                                        if (Material.HasProperty(propertyName))
                                        {

                                            Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                            Material.EnableKeyword("_TRANSLUCENT");
                                        }

                                        if (ContainsParam("$vertexcolor"))
                                        {

                                            textureName = GetParam("$vertexcolor");
                                            propertyName = "_VertexColor";

                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_VERTEX_COLOR");
                                            }
                                        }


                                        if (ContainsParam("$vertexalpha"))
                                        {
                                            textureName = GetParam("$vertexalpha");
                                            propertyName = "_VertexAlpha";

                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_VERTEX_ALPHA");
                                            }
                                        }


                                        if (ContainsParam("$vertexcolor")) if (ContainsParam("$vertexalpha"))
                                            {
                                                textureName = GetParam("$vertexcolor & $vertexalpha");

                                                propertyName = "_VertexColor & _VertexAlpha";

                                                if (Material.HasProperty(propertyName))
                                                {
                                                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                    Material.EnableKeyword("_VERTEX_COLOR & _VERTEX_ALPHA");
                                                }
                                            }





                                    }

                                    if (ContainsParam("$treesway"))
                                    {

                                        textureName = GetParam("$treesway");
                                        propertyName = "_TreeSway";

                                        if (Material.HasProperty(propertyName))
                                        {
                                            Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                            Material.EnableKeyword("_TREE_SWAY");
                                        }


                                    }


                                    if (ContainsParam("$lightmap"))
                                    {

                                        textureName = GetParam("$lightmap");
                                        propertyName = "_LightMap";


                                        if (Material.HasProperty(propertyName))
                                        {
                                            Material.SetTexture(textureName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                            Material.EnableKeyword("_LIGHTMAP");
                                        }


                                    }

                                    if (ContainsParam("$brightness"))
                                    {
                                        textureName = GetParam("$brightness");
                                        propertyName = "_Brightness";


                                        if (Material.HasProperty(propertyName))
                                        {
                                            Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                            Material.EnableKeyword("_BRIGHTNESS");


                                        }

                                        if (ContainsParam("$blendtintbybasealpha"))
                                        {
                                            textureName = GetParam("$blendtintbybasealpha");

                                            propertyName = "_BlendTintByBaseAlpha";


                                            if (!Material.HasProperty(propertyName))
                                            {

                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_BLEND_TINT_BY_BASE_ALPHA");


                                            }



                                        }

                                        if (ContainsParam("$blendmodulatetexture"))
                                        {

                                            textureName = GetParam("$blendmodulatetexture");
                                            propertyName = "_BlendModulateTexture";

                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_BLEND_MODULATE_TEXTURE");
                                            }
                                        }

                                        if (ContainsParam("$emissiveblend"))
                                        {


                                            textureName = GetParam("$emissiveblend");
                                            propertyName = "_EmissiveBlend";

                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_EMISSIVE_BLEND");
                                            }
                                        }

                                        if (ContainsParam("$envmaptint"))
                                        {
                                            textureName = GetParam("$envmaptint");
                                            propertyName = "_EnvMapTint";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ENVMAP_TINT");
                                            }
                                        }

                                        if (ContainsParam("$envmaptint"))
                                        {
                                            textureName = GetParam("$envmaptint");
                                            propertyName = "_EnvMapTint";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ENVMAP_TINT");
                                            }
                                        }
                                        if (ContainsParam("$envmapsphere"))
                                        {
                                            textureName = GetParam("$envmapsphere");
                                            propertyName = "_EnvMapSphere";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ENVMAP_SPHERE");
                                            }
                                        }
                                        if (ContainsParam("$envmapsaturation"))
                                        {
                                            textureName = GetParam("$envmapsaturation");
                                            propertyName = "_EnvMapSaturation";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ENVMAP_SATURATION");
                                            }
                                        }
                                        if (ContainsParam("$envmapoptional"))
                                        {
                                            textureName = GetParam("$envmapoptional");
                                            propertyName = "_EnvMapOptional";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ENVMAP_OPTIONAL");
                                            }
                                        }
                                        if (ContainsParam("$envmapmode"))
                                        {
                                            textureName = GetParam("$envmapmode");
                                            propertyName = "_EnvMapMode";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ENVMAP_MODE");
                                            }
                                        }
                                        if (ContainsParam("$envmaptint"))
                                        {
                                            textureName = GetParam("$envmaptint");
                                            propertyName = "_EnvMapTint";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ENVMAP_TINT");
                                            }
                                        }
                                        if (ContainsParam("$envmapmasktransform"))
                                        {
                                            textureName = GetParam("$envmapmasktransform");
                                            propertyName = "_EnvMapMaskTransform";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ENVMAP_MASK_TRANSFORM");
                                            }
                                        }
                                        if (ContainsParam("$envmapmaskframe"))
                                        {
                                            textureName = GetParam("$envmapmaskframe");
                                            propertyName = "_EnvMapMaskFrame";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                if (Material.HasProperty("$envmapmaskscale"))

                                                    Material.SetTextureScale("_EnvMapMask", GetVector2("$envmapmaskscale", true));

                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ENVMAP_MASK_FRAME");
                                            }
                                        }
                                        if (ContainsParam("$envmapcontrast"))
                                        {
                                            textureName = GetParam("$envmapcontrast");
                                            propertyName = "_EnvMapConstrast";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ENVMAP_CONSTRAST");
                                            }
                                        }
                                        if (ContainsParam("$envmapanisotropy"))
                                        {
                                            textureName = GetParam("$envmapanisotropy");
                                            propertyName = "_EnvMapAnisotropy";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                if (ContainsParam("$envmapanisotropyscale"))
                                                    Material.SetTextureScale("_EnvMapAnisotropy", GetVector2("$envmapanisotropyscale", true));

                                                Material.EnableKeyword("_ENVMAP_ANISOSTROPY");
                                            }
                                        }
                                        if (ContainsParam("$normalmap"))
                                        {
                                            textureName = GetParam("$normalmap");
                                            propertyName = "_NormalMap";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                if (ContainsParam("$bumpscale"))
                                                    Material.SetTextureScale("_Bump", GetVector2("$bumpscale", true));
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_NORMAL_MAP");
                                            }
                                        }
                                        if (ContainsParam("$softwareskin"))
                                        {
                                            textureName = GetParam("$softwareskin");
                                            propertyName = "_SoftwareSkin";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_SOFTWARE_SKIN");
                                            }
                                        }
                                        if (ContainsParam("%PlayerClip"))
                                        {
                                            textureName = GetParam("%PlayerClip");
                                            propertyName = "_PlayerClip";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_PLAYER_CLIP");
                                            }
                                        }
                                        if (ContainsParam("$selfillumfresnel"))
                                        {
                                            textureName = GetParam("$selfillumfresnel");
                                            propertyName = "_SelfIllumFresnel";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_SELFILLUM_FRESNEL");
                                            }
                                        }
                                        if (ContainsParam("$spriteorientation"))
                                        {
                                            textureName = GetParam("$spriteorientation");
                                            propertyName = "_SpriteOrientation";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_SPRITE_ORIENTATION");
                                            }
                                        }
                                        if (ContainsParam("$seamless scale"))
                                        {
                                            textureName = GetParam("$seamless scale");
                                            propertyName = "_SeamLessScale";


                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_SEAMLESS_SCALE");
                                            }
                                        }

                                        if (ContainsParam("$alpha"))
                                        {
                                            textureName = GetParam("$alpha");
                                            propertyName = "_Alpha";

                                            if (Material.HasProperty(propertyName))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ALPHA");
                                            }
                                        }
                                        if (ContainsParam("$alphatest"))
                                        {
                                            textureName = GetParam("$alphatest");
                                            propertyName = "_AlphaTest";

                                            if (Material.HasProperty("$alphatest"))
                                            {
                                                Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                Material.EnableKeyword("_ALPHA_TEST");


                                            }


                                            if (ContainsParam("$ambientocclusion"))
                                            {
                                                textureName = GetParam("$ambientocclusion");
                                                propertyName = "_AmbientOcclusion";

                                                if (Material.HasProperty(propertyName))
                                                {
                                                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                    Material.EnableKeyword("_AMBIENT_OCCLUSION");
                                                }
                                            }

                                            if (ContainsParam("$allowdiffusemodulation"))
                                            {
                                                textureName = GetParam("$allowdiffusemodulation");
                                                propertyName = "_AllowDiffuseModulation";

                                                if (Material.HasProperty(propertyName))
                                                {
                                                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                    Material.EnableKeyword("_AMBIENT_DIFFUSE_MODULATION");
                                                }
                                            }
                                            if (ContainsParam("$bumpbasetexture2withbumpmap"))
                                            {
                                                textureName = GetParam("$bumpbasetexture2withbumpmap");
                                                propertyName = "_BumpBaseTexture2WithBumpMap";

                                                if (Material.HasProperty(propertyName))
                                                {
                                                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                    Material.EnableKeyword("_BUMPBASE_TEXTURE_2_WITH_BUMPMAP");
                                                }
                                            }
                                            if (ContainsParam("$basetexture"))
                                            {
                                                textureName = GetParam("$basetexture");
                                                propertyName = "BaseTexture";

                                                if (Material.HasProperty(propertyName))
                                                {
                                                    if (ContainsParam("$basetexturetransform"))
                                                        Material.SetTextureScale("BaseTexture", GetVector2("$basetexturetransform", true));
                                                    Material.SetTexture(propertyName, uResourceManager.LoadTexture(textureName, ExportData: new String[,] { { FileName, propertyName } })[0, 0]);
                                                    Material.EnableKeyword("_BASE_TEXTURE");
                                                }
                                            }


                                        }
                                    }
                                }
                            }

                        }
                    }




                }
            }

        }



        private Texture2D LoadTexture(string textureName)
        {
            var texture = uResourceManager.LoadTexture(textureName, ExportData: new string[,] { { FileName, "_MainTex" } })[0, 0];

            if (texture != null)
            {
                string lowerCaseName = textureName.ToLower();

                // Check for normal map keywords
                if (lowerCaseName.Contains("_bumpmap") || lowerCaseName.Contains("_normalmap") || lowerCaseName.Contains("_ssbump"))
                {
                    // Convert to a normal map
                    return ProcessAsNormalMap(texture);
                }
            }


            return uResourceManager.LoadTexture(textureName, ExportData: new string[,] { { FileName, "_MainTex" } })[0, 0];
    


        }

        public Shader GetShader(string shader, bool hasAlpha = false)
        {
            if (shader.ToLower() == "skybox" && GraphicsSettings.defaultRenderPipeline is HDRenderPipelineAsset)
            {
                SetHDRPSky();
                // Dynamically load the first available skybox as HDRP HDRI Sky if HDRP is active

                return null;
            }



            switch (shader.ToLower())
            {
                // Major shaders for environments, models, and generic


                case "lightmappedgeneric": return Shader.Find(uLoader.LightmappedGenericShader);
                case "vertexlitgeneric": return Shader.Find(uLoader.VertexLitGenericShader);
                case "unlitgeneric": return Shader.Find(uLoader.UnlitGeneric);
                case "worldvertextransition": return Shader.Find(uLoader.WorldVertexTransitionShader);

                // Special shaders for environmental, reflective, or translucent effects
                case "refract": return Shader.Find("HDRP/Lit");
                case "water": return Shader.Find("HDRP/Water");

                case "translucenttwotexture": return Shader.Find("Transparent/DoubleTexture");

                // Complex shaders with phong and rim-lighting effects
                case "vertexlitgeneric_phong": return Shader.Find("HDRP/Lit");
                case "reflective": return Shader.Find("HDRP/Lit");

                // Legacy and deprecated shaders
                case "du_dvmap": return Shader.Find("HDRP/Lit");
                case "reflectiveglass": return Shader.Find("HDRP/Lit");

                // Default fallback
                default: return Shader.Find("HDRP/Lit");
            }

        }
        private void SetHDRPSky()
        {
            // Ensure HDRP Volume setup exists in the scene
            Volume volume = UnityEngine.Object.FindFirstObjectByType<Volume>();
            if (volume == null)
            {
                GameObject volumeObject = new GameObject("HDRP Volume");
                volume = volumeObject.AddComponent<Volume>();
                volume.isGlobal = true;
                volume.priority = 1;
            }

            // Check for or add an HDRI Sky setting
            if (!volume.profile.TryGet<HDRISky>(out HDRISky hdriSky))
            {
                hdriSky = volume.profile.Add<HDRISky>(true);
            }

            // Search for the first available .vmt skybox file in the directory
            var vmtFiles = Directory.GetFiles(sourceSkyboxPath, "*.vmt");
            if (vmtFiles.Length == 0)
            {
                Debug.LogError("No .vmt files found in the specified skybox directory.");
                return;
            }

            foreach (var vmtFilePath in vmtFiles)
            {
                string skyboxName = Path.GetFileNameWithoutExtension(vmtFilePath);
                VMTLoader.VMTFile vmtFile = VMTLoader.ParseVMTFile(vmtFilePath);
                if (vmtFile == null || string.IsNullOrEmpty(vmtFile.basetexture))
                {
                    Debug.LogWarning($"Failed to load VMT file or base texture not found: {vmtFilePath}");
                    continue;
                }

                // Load the VTF file as Texture2D
                string vtfPath = Path.Combine(sourceSkyboxPath, vmtFile.basetexture + ".vtf");
                Texture2D skyboxTexture = LoadVTFTexture(vtfPath);

                if (skyboxTexture == null)
                {
                    Debug.LogWarning($"Failed to load skybox texture from {vtfPath}");
                    continue;
                }

                // Convert to Cubemap
                Cubemap cubemap = ConvertToCubemap(skyboxTexture);
                if (cubemap == null)
                {
                    Debug.LogError("Cubemap conversion failed.");
                    return;
                }

                // Assign the cubemap to HDRI Sky
                hdriSky.hdriSky.value = cubemap;
                hdriSky.exposure.value = 1.0f;
                hdriSky.rotation.value = 0.0f;
                Debug.Log($"Skybox {skyboxName} loaded and converted to cubemap successfully.");
                return; // Exit after successfully loading the first valid skybox
            }

            Debug.LogError("No valid skybox textures found in the specified directory.");
        }

        private Cubemap ConvertToCubemap(Texture2D texture)
        {
            // Ensure the texture is readable
       

            int cubemapSize = 16384; // Adjust cubemap resolution if needed
            Cubemap cubemap = new Cubemap(cubemapSize, TextureFormat.RGBA32, true);

            // Loop through each face of the cubemap
            for (int faceIndex = 0; faceIndex < 6; faceIndex++)
            {
                CubemapFace face = (CubemapFace)faceIndex;
                Color[] faceColors = new Color[cubemapSize * cubemapSize];

                for (int y = 0; y < cubemapSize; y++)
                {
                    for (int x = 0; x < cubemapSize; x++)
                    {
                        // Sample texture and assign it to the cubemap face
                        Vector3 direction = GetDirectionFromCubemapFace(face, x, y, cubemapSize);
                        faceColors[x + y * cubemapSize] = SampleTexture(texture, direction);
                    }
                }

                cubemap.SetPixels(faceColors, face);
            }

            cubemap.Apply();
            return cubemap;
        }

        private Vector3 GetDirectionFromCubemapFace(CubemapFace face, int x, int y, int size)
        {
            float u = (x + 0.5f) / size * 2 - 1; // Map pixel to [-1, 1]
            float v = (y + 0.5f) / size * 2 - 1;

            switch (face)
            {
                case CubemapFace.PositiveX: return new Vector3(1, -v, -u);
                case CubemapFace.NegativeX: return new Vector3(-1, -v, u);
                case CubemapFace.PositiveY: return new Vector3(u, 1, v);
                case CubemapFace.NegativeY: return new Vector3(u, -1, -v);
                case CubemapFace.PositiveZ: return new Vector3(u, -v, 1);
                case CubemapFace.NegativeZ: return new Vector3(-u, -v, -1);
                default: return Vector3.zero;
            }
        }

        private Color SampleTexture(Texture2D texture, Vector3 direction)
        {
            // Convert direction to spherical coordinates
            float u = 0.5f + Mathf.Atan2(direction.z, direction.x) / (2 * Mathf.PI);
            float v = 0.5f - Mathf.Asin(direction.y) / Mathf.PI;

            // Sample the texture
            return texture.GetPixelBilinear(u, v);
        }


        private Texture2D LoadVTFTexture(string vtfPath)
        {
            if (!File.Exists(vtfPath))
            {
                Debug.LogWarning($"VTF file not found at {vtfPath}");
                return null;
            }

            using (FileStream stream = new FileStream(vtfPath, FileMode.Open))
            {
                VTFFile vtfFile = new VTFFile(stream, vtfPath);
                if (vtfFile.Frames == null || vtfFile.Frames.GetLength(0) == 0)
                {
                    Debug.LogError("Failed to parse VTF file or no frames found.");
                    return null;
                }

                // Return the first frame as the Texture2D
                return vtfFile.Frames[0, 0];
            }

           

        }
        private Texture2D ProcessAsNormalMap(Texture2D texture)
        {
            // Ensure the texture is marked as a normal map
            if (!texture.isReadable)
            {
                Debug.LogWarning("Texture is not readable; ensure 'Read/Write Enabled' is checked in the import settings.");
                return texture;
            }

            // Convert texture format to Unity's normal map format
            Texture2D normalMap = new Texture2D(texture.width, texture.height, TextureFormat.ARGB32, false);
            Color[] pixels = texture.GetPixels();

            for (int i = 0; i < pixels.Length; i++)
            {
                pixels[i] = new Color(pixels[i].r, pixels[i].g, 1.0f, pixels[i].a); // Remap to normal map
            }

            normalMap.SetPixels(pixels);
            normalMap.Apply();

            return normalMap;
        }
        private Texture2D ProcessAsSSBumpMap(Texture2D texture)
        {
            // Ensure the texture is readable
            if (!texture.isReadable)
            {
                Debug.LogWarning("Texture is not readable; ensure 'Read/Write Enabled' is checked in the import settings.");
                return texture;
            }

            // Convert SSBump to a normal map format
            Texture2D ssbumpMap = new Texture2D(texture.width, texture.height, TextureFormat.ARGB32, false);
            Color[] pixels = texture.GetPixels();

            for (int i = 0; i < pixels.Length; i++)
            {
                // Convert SSBump data to a normal map (approximation)
                float x = pixels[i].r * 2 - 1;
                float y = pixels[i].g * 2 - 1;
                float z = Mathf.Sqrt(1 - Mathf.Clamp01(x * x + y * y)); // Compute Z for a normalized vector

                pixels[i] = new Color(x * 0.5f + 0.5f, y * 0.5f + 0.5f, z * 0.5f + 0.5f, pixels[i].a);
            }

            ssbumpMap.SetPixels(pixels);
            ssbumpMap.Apply();

            return ssbumpMap;
        }


    }
}


  