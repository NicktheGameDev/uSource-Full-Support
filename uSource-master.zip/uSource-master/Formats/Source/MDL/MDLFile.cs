﻿
/*
 * Enhanced MDLFile Script for Unity
 * Features:
 * - Comprehensive support for Source Engine MDL features including animations, flexes, jiggle bones, and eyeball tracking.
 * - Modular and clear structure for easy maintenance.
 */


using JetBrains.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using UnityEditor;

#if UNITY_EDITOR
using UnityEditor.Animations;
using UnityEditor.PackageManager.UI;

#endif
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.Events;
using uSource;
using uSource.Formats.Source.MDL;
using uSource.Formats.Source.VTF;
using uSource.MathLib;
using static uSource.Formats.Source.MDL.StudioStruct;



namespace uSource.Formats.Source.MDL
{


    public class MDLFile : StudioStruct
    {
        public studiohdr_t MDL_Header;

        // Variables for new data
        public mstudioflex_t[] MDL_Flexes;
        public mstudiojigglebone_t[] MDL_JiggleBones;
        public mstudioeyeball_t[] MDL_Eyeballs;

        public mstudioflexdesc_t[] MDL_FlexDescs;
        // Maksymalna liczba zdarzeń do obsługi
        private const int MAX_EVENTS_ALLOWED = 1000;


        public String[] MDL_BoneNames;
        public mstudiobone_t[] MDL_StudioBones;

        //animations
        private mstudioseqdesc_t[] _MDL_SeqDescriptions;
        public mstudioseqdesc_t[] MDL_SeqDescriptions => _MDL_SeqDescriptions ??= new mstudioseqdesc_t[MDL_Header.localseq_count];

        public mstudioanimdesc_t[] MDL_AniDescriptions;

        public List<AniInfo> Animators;
        public SeqInfo[] Sequences;

        private static mstudioevent_t[] MDL_Events;
        //animations
        public bool EnableFlexes { get; set; } = true;
        public bool EnableJiggleBones { get; set; } = true;
        public bool EnableEyeMovement { get; set; } = true;
        //Materials
        public mstudiotexture_t[] MDL_TexturesInfo;
        public String[] MDL_TDirectories;
        public String[] MDL_Textures;
        //Materials

        mstudiohitboxset_t[] MDL_Hitboxsets;
        Hitbox[][] Hitboxes;
        /// <summary>
        /// Dodaje blendshapes na podstawie danych flexów zawartych w modelu MDL.
        /// </summary>
        /// <param name="mesh">Siatka modelu, do której dodawane są blendshapes.</param>
        /// <param name="mdlData">Surowe dane MDL.</param>
        /// <param name="baseOffset">Podstawowy offset danych.</param>
        /// 
        public enum DetailMode
        {
            None, // Parse all lod's
            Lowest, // Parse only last lod's
            Low, // Parse only low lod's
            Medium, // Parse only mid lod's
            High // Parse only high lod's
        }

        // Ensuring HandleSequenceEvents is used

        // Ensuring OnTriggerEnter is used
        private void Use_OnTriggerEnter()
        {
            OnTriggerEnter();

            Use_OnTriggerEnter();
        }

        // Ensuring ApplyAnimationClip is used
        private void Use_ApplyAnimationClip() { ApplyAnimationClip(new AnimationClip(), "anim"); }

        // Ensuring PopulateKeyframesForAnimator is used
        private void Use_PopulateKeyframesForAnimator()


        {
            PopulateKeyframesForAnimator(new int(), new int(), new AniInfo(), new mstudiobone_t[0]);

            Use_PopulateKeyframesForAnimator();
        }


        // Ensuring SetIndices is used




        // Ensuring UpdateProceduralBones is used
        private void Use_UpdateProceduralBones() { UpdateProceduralBones(Time.deltaTime); }

        // En

        // Ensuring PlayAnimatorsByCategory is used
        private void Use_PlayAnimatorsByCategory()
        {


            PlayAnimatorsByCategory("advanced");
            Use_PlayAnimatorsByCategory();
        }

        // Ensuring AddAllAnimators is used
        private void Use_AddAllAnimators()

        {
            AddAllAnimators();

            Use_AddAllAnimators();

        }

        // Ensuring IrisScale is used
        public static void Use_AnimationClipCreator() { var instance = new AnimationClipCreator(); Debug.Log("Instance of AnimationClipCreator created."); }

        public void ProcessModel(GameObject modelObject)
        {
            Debug.Log($"Processing model: {MDL_Header.Name}");

            // Flexes
            if (EnableFlexes && MDL_Flexes != null)
            {
                ProcessFlexes(modelObject);
            }


            // Jiggle Bones
            if (EnableJiggleBones && MDL_JiggleBones != null)
            {
                ApplyJiggleBones(modelObject);
            }

            // Eye Movement
            if (EnableEyeMovement && MDL_Eyeballs != null)
            {
                ApplyEyeMovement(modelObject);
            }


            // Animations
            InitializeAnimatorSystem(modelObject);


#if UNITY_EDITOR
            JiggleBone.EnsureAnimatorIsPlaying(modelObject);
            // Automatically play the first animation
            AnimatorManager animationManager = new AnimatorManager(modelObject);
            string firstAnimation = animationManager.FirstAnimationName();
            if (!string.IsNullOrEmpty(firstAnimation))
            {
                animationManager.PlayAnimator(firstAnimation, loop: true);
            }
#endif
        }

        private void ApplyJiggleBones(GameObject modelObject)
        {
            Debug.Log("Applying jiggle bones...");

            // Ensure MDL_JiggleBones is valid
            if (MDL_JiggleBones == null || MDL_JiggleBones.Length == 0)
            {

                return;
            }

            // Initialize Bones array
            Transform[] Bones = new Transform[MDL_Header.bone_count];
            PopulateBonesArray(modelObject, Bones);

            // Iterate and apply jiggle bones
            foreach (var jiggleBone in MDL_JiggleBones)
            {
                Transform bone = Bones[jiggleBone.bone];
                if (bone == null)
                {

                    continue;
                }

                JiggleBone jiggle = new JiggleBone(bone);
                jiggle.Update(Time.deltaTime, modelObject.transform.position);
            }

            Debug.Log("Jiggle bones applied successfully.");
        }


        private void PopulateBonesArray(GameObject modelObject, Transform[] Bones)
        {
            for (int i = 0; i < MDL_Header.bone_count; i++)
            {
                string boneName = MDL_BoneNames[i];
                Transform boneTransform = modelObject.transform.Find(boneName);

                if (boneTransform != null)
                {
                    Bones[i] = boneTransform;
                }
                else
                {

                }
            }
        }

        private AnimatorManager animationManager;

        public void InitializeAnimatorSystem(GameObject modelObject)
        {
            AnimatorManager animationManager = new AnimatorManager(modelObject);

            foreach (var sequence in Sequences ?? Array.Empty<SeqInfo>())
            {
                if (sequence.ani == null)
                {
                    continue;
                }

                Debug.Log($"Processing sequence: {sequence.name}");
                foreach (var animation in sequence.ani ?? new List<AniInfo>())
                {
                    if (animation?.clip == null)
                    {

                        continue;
                    }

                    string clipName = $"{sequence.name}_{animation.name}";
                    Debug.Log($"Adding clip: {clipName}");
                    animationManager.AddAnimationClip(clipName, animation.clip);
                }

                AnimationLoader.LoadAnimationsIntoAnimator(modelObject);

            }


            animationManager.UseAllAnims();
            Debug.Log($"Animator system initialized for {MDL_Header.Name} with {animationManager.AnimationClipCount} animations.");
        }

        private void BlendAnimators(string from, string to, float blendDuration = 0.5f)
        {
            animationManager.BlendToAnimator(to, blendDuration);
        }

        private void HandleAnimatorEvents(float deltaTime)
        {
            if (Sequences.Length == 0) return;

            foreach (var sequence in Sequences)
            {
                foreach (var eventObj in sequence.seq.Events)
                {
                    if (eventObj.frame == Mathf.FloorToInt(animationManager.CurrentTime))
                    {
                        Debug.Log($"Triggered event: {eventObj.eventname}");
                        onSequenceTriggered?.Invoke(eventObj);
                    }
                }
            }
        }
        private void HandleSequenceEvents(mstudioseqdesc_t sequence, int currentFrame)
        {
            foreach (var evt in sequence.Events)
            {
                if (evt.frame == currentFrame)
                {
                    Debug.Log($"Event triggered: ID {evt.eventID}, Options: {evt.options}");
                    // Handle the event based on ID or options
                    TriggerCustomEvent(evt);
                }
            }
        }


        public static void TriggerCustomEvent(mstudioevent_t evt)
        {
            // Example: Play a sound or spawn an object
            if (evt.eventID == 1001) // Replace with your event ID
            {
                Debug.Log($"Playing sound: {evt.options}");
            }
            else if (evt.eventID == 1002) // Example: spawn object
            {
                Debug.Log($"Spawning object with parameters: {evt.options}");
            }
        }
        private Transform[] GetModelBones(GameObject modelObject)
        {
            Transform[] bones = new Transform[MDL_Header.bone_count];

            for (int i = 0; i < MDL_Header.bone_count; i++)
            {
                string boneName = MDL_BoneNames[i];
                Transform boneTransform = modelObject.transform.Find(boneName);

                if (boneTransform != null)
                {
                    bones[i] = boneTransform;
                }
                else
                {
                    Debug.LogWarning($"Bone '{boneName}' not found in the model hierarchy.");
                }
            }

            return bones;
        }

        private void ApplyEyeMovement(GameObject modelObject)
        {
            Debug.Log("Applying eye movement...");
            if (Camera.main == null)
            {
                Debug.LogWarning("No main camera found for eye movement!");
                return;
            }

            Transform[] bones = GetModelBones(modelObject);
            Vector3 cameraPosition = Camera.main.transform.position;

            foreach (var eye in MDL_Eyeballs)
            {
                Transform boneTransform = bones[eye.bone];
                if (boneTransform == null) continue;

                Vector3 targetDirection = (cameraPosition - boneTransform.position).normalized;

                // Smooth rotation towards the camera
                Quaternion targetRotation = Quaternion.LookRotation(targetDirection);
                boneTransform.rotation = Quaternion.Slerp(boneTransform.rotation, targetRotation, 0.1f);

                Debug.Log($"Eye bone {eye.bone} tracking camera.");
            }
        }




        private int CurrentFrame;

        // Metoda do aktualizacji klatek na podstawie czasu animacji
        private Animator AnimatorComponent;

        private void InitializeAnimatorComponent(GameObject modelObject)
        {
            // Sprawdź, czy obiekt ma komponent Animation
            AnimatorComponent = modelObject.GetComponent<Animator>();

            // Jeśli komponent nie istnieje, dodaj go
            if (AnimatorComponent == null)
            {
                AnimatorComponent = modelObject.AddComponent<Animator>();
                Debug.Log("Animator component added to the model.");
            }
        }



        public void PlayAnimator(string animationName)
        {
            if (AnimatorComponent == null)
            {
                return;
            }

            if (AnimatorComponent != null)
            {
                AnimatorComponent.Play(animationName);
                Debug.Log($"Playing animation: {animationName}");
            }
            else
            {
            }
        }
        private void AssignAnimationClips()
        {
            if (AnimatorComponent == null)
            {
                return;
            }
            int index = new();
            foreach (var seqInfo in Sequences)
            {

                if (seqInfo.ani != null && seqInfo.ani[index] != null)
                {
                    AnimatorComponent.GetAnimatorTransitionInfo(seqInfo.name.Length);
                    Debug.Log($"Added animation clip: {seqInfo.name}");
                }
                else
                {
                }
            }

            if (Sequences != null &&
         Sequences.Length > 0 &&
         Sequences != null &&
         Sequences[0].ani != null &&
         index >= 0 &&
         index < Sequences[index].ani.Count &&
         Sequences[0].ani[index] != null)
            {
                AnimatorComponent = Sequences[0].ani[index]; // Ustaw pierwszy klip jako domyślny
            }
            else
            {

            }

        }
        static int index = new();
        private List<Animator> GetAnimatorComponent()
        {
            return AnimComponent;
        }

        private void UpdateCurrentFrame(List<Animator> animatorComponent)
        {
            {

                CurrentFrame = Mathf.FloorToInt(animatorComponent[index].parameterCount * AnimatorComponent.playbackTime);
            }
        }
        [System.Serializable]
        public class SequenceEvent : UnityEvent<mstudioevent_t> { }

        [SerializeField]
        private SequenceEvent onSequenceTriggered = new SequenceEvent();

        public SequenceEvent OnSequenceTriggered => onSequenceTriggered;

        private void HandleFrameEvents(int currentFrame)
        {
            if (MDL_Events == null || MDL_Events.Length == 0)
            {
                return;
            }

            // Iteracja przez wszystkie zdarzenia

            List<MDL_Event> mDL_Event = new();
            foreach (var mdlEvent in mDL_Event)
            {
                if (MDL_Event.frame == currentFrame)
                {
                    Debug.Log($"Event triggered: {MDL_Event.eventname} on frame {currentFrame}");

                    // Obsługa wyzwalania zdarzenia
                    TriggerEvent(mDL_Event.Count);
                }
            }
        }

        private void Update()
        {
            foreach (var sequence in Sequences)
            {
                if (sequence.seq.numevents > 0)
                {
                    for (int i = 0; i < sequence.seq.numevents; i++)
                    {
                        // Sprawdź, czy bieżąca klatka odpowiada klatce zdarzenia
                        if (CurrentFrame == eventsCount)
                        {
                            // Wyzwól zdarzenie o indeksie `i`
                            TriggerEvent(i);

                            // Wywołaj zdarzenie UnityEvent przypisane w edytorze
                            if (OnSequenceTriggered != null)
                            {
                                OnSequenceTriggered.Invoke(new mstudioevent_t());
                            }

                            if (animationManager != null)
                            {
                                animationManager.UpdateAnimator(Time.deltaTime);
                                HandleAnimatorEvents(Time.deltaTime);
                            }

                        }
                    }
                }
            }

            // Sprawdzanie i aktualizacja bieżącej klatki w animacji
            {
                // Aktualizuj bieżącą klatkę
                UpdateCurrentFrame(GetAnimatorComponent());

                // Obsłuż zdarzenia na aktualnej klatce
                HandleFrameEvents(CurrentFrame);
            }

        }


        /// <summary>
        /// Walidacja danych flexów przed przetworzeniem.
        /// </summary>


        /// <summary>
        /// Pobiera nazwę facjalną dla flexa.
        /// </summary>


        /// <summary>
        /// Odczytuje null-terminated string z danych binarnych.
        /// </summary>
        public static string ReadNullTerminatedString(byte[] data, int offset, int maxLength = 256)
        {
            int length = 0;
            while (length < maxLength && offset + length < data.Length && data[offset + length] != 0)
                length++;

            return Encoding.UTF8.GetString(data, offset, length);
        }



        public void OnTriggerEnter()
        {

            TriggerEvent(eventsCount);
        }
        // Eye movement integration

        private AnimatorOverrideController overrideController;

        public void ApplyAnimationClip(AnimationClip clip, string stateName)
        {
            if (animator == null)
            {
                animator = go.GetComponent<Animator>();
                if (animator == null)
                {
                    return;
                }
            }

            if (overrideController == null)
            {
                overrideController = new AnimatorOverrideController(animator.runtimeAnimatorController);
                animator.runtimeAnimatorController = overrideController;
            }

            overrideController[stateName] = clip;
            animator.Play(stateName);
        }

        public static void PopulateKeyframesForAnimator(int numFrames, int numBones, AniInfo aniInfo, mstudiobone_t[] bones)
        {
            for (int frame = 0; frame < numFrames; frame++)
            {
                for (int boneIndex = 0; boneIndex < numBones; boneIndex++)
                {
                    aniInfo.PosX[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].pos.x);
                    aniInfo.PosY[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].pos.y);
                    aniInfo.PosZ[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].pos.z);

                    aniInfo.RotX[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].rot.x);
                    aniInfo.RotY[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].rot.y);
                    aniInfo.RotZ[frame][boneIndex] = new Keyframe(frame / 30.0f, bones[boneIndex].rot.z);
                }
            }
        }





        private void ParseAnimatorBones(uReader reader, int animOffset, mstudioanimdesc_t studioAnim, AniInfo aniInfo)
        {
            int boneCount = MDL_Header.bone_count;
            for (int boneIndex = 0; boneIndex < boneCount; boneIndex++)
            {
                var bone = new AnimationBone(bone_, flags, numFrames)
                {
                    Bone = (byte)boneIndex,
                    Flags = (byte)studioAnim.flags,

                };

                aniInfo.AnimationBones.Add(bone);
            }
        }


        private void LoadEventsForSequence(int seqID, uReader FileStream, int sequenceOffset)
        {
            var sequence = MDL_SeqDescriptions[seqID];
            int eventCount = Math.Min(sequence.numevents, MAX_EVENTS_ALLOWED);

            if (eventCount <= 0)
            {
                Debug.Log($"Sequence {seqID} ({sequence.szlabelindex}) has no events.");
                return;
            }

            // Manual marshaling for event array due to array limitations.
            MDL_Events = new mstudioevent_t[eventCount];

            for (int i = 0; i < eventCount; i++)
            {
                int eventOffset = sequence.eventindex + (i * Marshal.SizeOf(typeof(mstudioevent_t)));

                if (!ValidateOffset(eventOffset, Marshal.SizeOf(typeof(mstudioevent_t)), FileStream.BaseStream.Length))
                {
                    continue;
                }

                FileStream.ReadTypeFixed(ref MDL_Events[i], Marshal.SizeOf(typeof(mstudioevent_t)), eventOffset);
            }

            Debug.Log($"Loaded {eventCount} events for sequence {seqID} ({sequence.szlabelindex}).");
        }


        public StudioBodyPart[] MDL_Bodyparts;

        public class mstudioseqdescOffsets
        {
            // Definicje offsetów dla pól struktury mstudioseqdesc_t
            public const int groupsize = 40;    // Offset dla groupsize
            public const int paramindex = 48;  // Offset dla paramindex
            public const int paramstart = 56;  // Offset dla paramstart
            public const int paramend = 64;    // Offset dla paramend
        }// Rozszerz

        public static bool ValidateOffset(int offset, int size, long streamLength)
        {
            if (offset < 0 || offset + size > streamLength)
            {
                return false;
            }
            return true;
        }

        FileStream fileStream;
        public MDLFile(Stream FileInput, mstudioevent_t[] MDL_Events, bool parseAnims = false, bool parseHitboxes = false)
        {
            using (uReader FileStream = new uReader(FileInput))
            {
                FileStream.ReadTypeFixed(ref MDL_Header, Marshal.SizeOf(typeof(studiohdr_t)));

                if (MDL_Header.id != 0x54534449) // 'IDST'
                    throw new FileLoadException("File signature does not match 'IDST'");

                Debug.Log($"Loading MDL file: {MDL_Header.Name}, version: {MDL_Header.version}");

                // Jeśli tablica zdarzeń jest pusta, inicjalizujemy ją
                MDL_Events = MDL_Events?.Length > 0 ? MDL_Events : new mstudioevent_t[MDL_Header.eventsindexed];

                // Parsowanie sekwencji
                _MDL_SeqDescriptions = new mstudioseqdesc_t[MDL_Header.localseq_count];
                for (int seqID = 0; seqID < MDL_Header.localseq_count; seqID++)
                {
                    int seqOffset = MDL_Header.localseq_offset + seqID * Marshal.SizeOf<mstudioseqdesc_t>();
                    FileStream.ReadType(ref MDL_SeqDescriptions[seqID], seqOffset);
                }

                // Inicjalizacja zdarzeń
                LoadEventsForSequence(0, FileStream, 0);

                // Odczyt kości


                //Bones
                #region Bones
                //Bones
                MDL_StudioBones = new mstudiobone_t[MDL_Header.bone_count];
                MDL_BoneNames = new String[MDL_Header.bone_count];
                for (Int32 BoneID = 0; BoneID < MDL_Header.bone_count; BoneID++)
                {
                    Int32 boneOffset = MDL_Header.bone_offset + (216 * BoneID);
                    FileStream.ReadTypeFixed(ref MDL_StudioBones[BoneID], 216, boneOffset);
                    MDL_BoneNames[BoneID] = FileStream.ReadNullTerminatedString(boneOffset + MDL_StudioBones[BoneID].sznameindex);
                }
                //Bones
                #endregion
                {

                    #region Sequence Parsing with Event Handling
                    #region Comprehensive Animator Parsing

                    if (parseHitboxes)
                    {
                        // Walidacja liczby hitboxów
                        if (MDL_Header.hitbox_count < 0 || MDL_Header.hitbox_count > 10000)
                        {
                            MDL_Header.hitbox_count = Mathf.Clamp(MDL_Header.hitbox_count, 0, 10000);
                        }


                        {
                            MDL_Hitboxsets = new mstudiohitboxset_t[MDL_Header.hitbox_count];
                            Hitboxes = new Hitbox[MDL_Header.hitbox_count][];

                            for (Int32 hitboxsetID = 0; hitboxsetID < MDL_Header.hitbox_count; hitboxsetID++)
                            {
                                Int32 hitboxsetOffset = MDL_Header.hitbox_offset + (12 * hitboxsetID);
                                if (!ValidateOffset(hitboxsetOffset, Marshal.SizeOf<mstudiohitboxset_t>(), FileStream.BaseStream.Length))
                                {
                                    continue;
                                }

                                FileStream.ReadType(ref MDL_Hitboxsets[hitboxsetID], hitboxsetOffset);
                                Hitboxes[hitboxsetID] = new Hitbox[MDL_Hitboxsets[hitboxsetID].numhitboxes];

                                for (Int32 hitboxID = 0; hitboxID < MDL_Hitboxsets[hitboxsetID].numhitboxes; hitboxID++)
                                {
                                    Int32 hitboxOffset = hitboxsetOffset + (68 * hitboxID) + MDL_Hitboxsets[hitboxsetID].hitboxindex;
                                    if (!ValidateOffset(hitboxOffset, Marshal.SizeOf<mstudiobbox_t>(), FileStream.BaseStream.Length))
                                    {
                                        continue;
                                    }

                                    Hitboxes[hitboxsetID][hitboxID].BBox = new mstudiobbox_t();
                                    FileStream.ReadType(ref Hitboxes[hitboxsetID][hitboxID].BBox, hitboxOffset);
                                }
                            }
                        }

                    }
                    if (parseAnims)
                    {
                        ParseSequences(FileStream);
                        ParseAnimationsForSequence(FileStream, sequence, new SeqInfo());
                        // Ensure that Animation and AniDescriptions arrays are initialized
                        if (MDL_Header.localanim_count > 0)
                        {
                            MDL_AniDescriptions = new mstudioanimdesc_t[MDL_Header.localanim_count];
                            Animators = new List<AniInfo>(MDL_Header.localanim_count);


                            for (int AnimID = 0; AnimID < MDL_Header.localanim_count; AnimID++)
                            {
                                int AnimOffset = MDL_Header.localanim_offset + (100 * AnimID);
                                FileStream.ReadTypeFixed(ref MDL_AniDescriptions[AnimID], 100, AnimOffset);

                                mstudioanimdesc_t StudioAnim = MDL_AniDescriptions[AnimID];
                                if (StudioAnim.flags == 0) continue; // Skip if animation description is invalid

                                string StudioAnimName = FileStream.ReadNullTerminatedString(AnimOffset + StudioAnim.sznameindex);
                                if (Animators == null)
                                {
                                    Animators = new List<AniInfo>(MDL_Header.localanim_count);

                                }

                                // Dodaj puste miejsca, aby upewnić się, że indeks jest dostępny
                                while (Animators.Count <= AnimID)
                                {
                                    Animators.Add(null);
                                }

                                // Teraz bezpiecznie przypisz wartość
                                Animators[AnimID] = new AniInfo { name = StudioAnimName, studioAnim = StudioAnim };

                                Debug.Log($"Added animation info at index {AnimID}: {StudioAnimName}");

                                Animators[AnimID].AnimationBones = new List<AnimationBone>();

                                // Initialize AnimationBones if necessary
                                FileStream.BaseStream.Position = AnimOffset;
                                long StartOffset = FileStream.BaseStream.Position;
                                int CurrentOffset = MDL_AniDescriptions[AnimID].animindex;
                                short NextOffset;

                                do
                                {
                                    FileStream.BaseStream.Position = StartOffset + CurrentOffset;
                                    byte BoneIndex = FileStream.ReadByte();
                                    byte BoneFlag = FileStream.ReadByte();
                                    NextOffset = FileStream.ReadInt16();
                                    CurrentOffset += NextOffset;

                                    if (BoneIndex < 0 || BoneFlag < 0) continue; // Skip invalid bone entries

                                    AnimationBone AnimatedBone = new AnimationBone(BoneIndex, BoneFlag, MDL_AniDescriptions[AnimID].numframes);
                                    AnimatedBone.ReadData(FileStream);
                                    Animators[AnimID].AnimationBones.Add(AnimatedBone);

                                } while (NextOffset != 0);

                                // Check if there are valid animation bones to process
                                if (Animators[AnimID].AnimationBones.Count > 0)
                                {
                                    List<AnimationBone> AnimatorBones = Animators[AnimID].AnimationBones;
                                    int NumBones = MDL_Header.bone_count;
                                    int NumFrames = StudioAnim.numframes;

                                    // Handle cases where frame count is too small
                                    bool FramesLess = NumFrames < 2;
                                    if (FramesLess) NumFrames += 1;

                                    ParseAnimatorBones(FileStream, AnimOffset, StudioAnim, Animators[AnimID]);

                                    // Initialize keyframes
                                    Animators[AnimID].PosX = new Keyframe[NumFrames][];
                                    Animators[AnimID].PosY = new Keyframe[NumFrames][];
                                    Animators[AnimID].PosZ = new Keyframe[NumFrames][];
                                    Animators[AnimID].RotX = new Keyframe[NumFrames][];
                                    Animators[AnimID].RotY = new Keyframe[NumFrames][];
                                    Animators[AnimID].RotZ = new Keyframe[NumFrames][];
                                    Animators[AnimID].RotW = new Keyframe[NumFrames][];

                                    for (int FrameID = 0; FrameID < NumFrames; FrameID++)
                                    {
                                        Animators[AnimID].PosX[FrameID] = new Keyframe[NumBones];
                                        Animators[AnimID].PosY[FrameID] = new Keyframe[NumBones];
                                        Animators[AnimID].PosZ[FrameID] = new Keyframe[NumBones];

                                        Animators[AnimID].RotX[FrameID] = new Keyframe[NumBones];
                                        Animators[AnimID].RotY[FrameID] = new Keyframe[NumBones];
                                        Animators[AnimID].RotZ[FrameID] = new Keyframe[NumBones];
                                        Animators[AnimID].RotW[FrameID] = new Keyframe[NumBones];
                                    }

                                    // Prepare keyframes for animation
                                    PrepareAnimatorKeyframes(Animators[AnimID], StudioAnim, NumFrames);

                                    for (int boneID = 0; boneID < NumBones; boneID++)
                                    {
                                        AnimationBone AnimBone = AnimatorBones.FirstOrDefault(x => x.Bone == boneID);

                                        for (int frameID = 0; frameID < NumFrames; frameID++)
                                        {
                                            float time = frameID / StudioAnim.fps;
                                            mstudiobone_t StudioBone = MDL_StudioBones[boneID];

                                            Vector3 Position = StudioBone.pos;
                                            Vector3 Rotation = StudioBone.rot;

                                            if (AnimBone != null)
                                            {
                                                if ((AnimBone.Flags & STUDIO_ANIM_RAWROT) > 0)
                                                    Rotation = MathLibrary.ToEulerAngles(AnimBone.pQuat48);

                                                if ((AnimBone.Flags & STUDIO_ANIM_RAWROT2) > 0)
                                                    Rotation = MathLibrary.ToEulerAngles(AnimBone.pQuat64);

                                                if ((AnimBone.Flags & STUDIO_ANIM_RAWPOS) > 0)
                                                    Position = AnimBone.pVec48;

                                                if ((AnimBone.Flags & STUDIO_ANIM_ANIMROT) > 0)
                                                    Rotation += AnimBone.FrameAngles[(FramesLess && frameID != 0) ? frameID - 1 : frameID].Multiply(StudioBone.rotscale);

                                                if ((AnimBone.Flags & STUDIO_ANIM_ANIMPOS) > 0)
                                                    Position += AnimBone.FramePositions[(FramesLess && frameID != 0) ? frameID - 1 : frameID].Multiply(StudioBone.posscale);

                                                if ((AnimBone.Flags & STUDIO_ANIM_DELTA) > 0)
                                                {
                                                    Position = Vector3.zero;
                                                    Rotation = Vector3.zero;
                                                }
                                            }

                                            // Update Keyframes
                                            Animators[AnimID].PosX[frameID][boneID] = new Keyframe(time, Position.x);
                                            Animators[AnimID].PosY[frameID][boneID] = new Keyframe(time, Position.y);
                                            Animators[AnimID].PosZ[frameID][boneID] = new Keyframe(time, Position.z);
                                            Animators[AnimID].RotX[frameID][boneID] = new Keyframe(time, Rotation.x);
                                            Animators[AnimID].RotY[frameID][boneID] = new Keyframe(time, Rotation.y);
                                            Animators[AnimID].RotZ[frameID][boneID] = new Keyframe(time, Rotation.z);

                                        }
                                    }
                                }
                            }
                        }

                        // Sequences Handling - Further Steps
                        if (MDL_Header.localseq_count > 0)
                        {
                            _MDL_SeqDescriptions = new mstudioseqdesc_t[MDL_Header.localseq_count];
                            Sequences = new SeqInfo[MDL_Header.localseq_count];

                            for (int seqID = 0; seqID < MDL_Header.localseq_count; seqID++)
                            {
                                int sequenceOffset = MDL_Header.localseq_offset + (212 * seqID);
                                FileStream.ReadTypeFixed(ref MDL_SeqDescriptions[seqID], 212, sequenceOffset);

                                mstudioseqdesc_t Sequence = MDL_SeqDescriptions[seqID];
                                if (Sequence.flags != 0)
                                {
                                    Sequences[seqID] = new SeqInfo { name = FileStream.ReadNullTerminatedString(sequenceOffset + Sequence.szlabelindex), seq = Sequence };

                                    // Read Animation indices for sequences
                                    FileStream.BaseStream.Position = sequenceOffset + Sequence.animindexindex;

                                    var animID = FileStream.ReadShortArray(Sequence.groupsize[0] * Sequence.groupsize[1]);
                                    foreach (var id in animID)
                                    {
                                        if (id >= 0 && id < Animators.Count && Animators[id] != null)
                                        {
                                            Sequences[seqID] = new SeqInfo
                                            {
                                                name = Sequences[seqID].name,
                                                seq = Sequences[seqID].seq,
                                                ani = new List<AniInfo>()
                                            };

                                            Sequences[seqID].ani.Add(Animators[animID[0]]);
                                            Sequences[seqID].ani.Add(Animators[id]);
                                        }
                                        else
                                        {
                                        }
                                    }


                                    LoadEventsForSequence(seqID, FileStream, sequenceOffset);
                                }
                            }
                        }
                    }
                    void PrepareAnimatorKeyframes(AniInfo animation, mstudioanimdesc_t studioAnim, int numBones)
                    {
                        int numFrames = studioAnim.numframes;
                        if (numFrames < 2) numFrames += 1;



                        for (int frameID = 0; frameID < numFrames; frameID++)
                        {

                        }
                    }

                    Debug.Log("MDL file successfully loaded.");


                    #region Materials
                    //Materials
                    MDL_TexturesInfo = new mstudiotexture_t[MDL_Header.texture_count];
                    MDL_Textures = new String[MDL_Header.texture_count];
                    for (Int32 TexID = 0; TexID < MDL_Header.texture_count; TexID++)
                    {
                        Int32 TextureOffset = MDL_Header.texture_offset + (64 * TexID);
                        FileStream.ReadTypeFixed(ref MDL_TexturesInfo[TexID], 64, TextureOffset);
                        MDL_Textures[TexID] = FileStream.ReadNullTerminatedString(TextureOffset + MDL_TexturesInfo[TexID].sznameindex);
                    }

                    Int32[] TDirOffsets = new Int32[MDL_Header.texturedir_count];
                    MDL_TDirectories = new String[MDL_Header.texturedir_count];
                    for (Int32 DirID = 0; DirID < MDL_Header.texturedir_count; DirID++)
                    {
                        FileStream.ReadTypeFixed(ref TDirOffsets[DirID], 4, MDL_Header.texturedir_offset + (4 * DirID));
                        MDL_TDirectories[DirID] = FileStream.ReadNullTerminatedString(TDirOffsets[DirID]);
                    }
                    //Materials
                    #endregion

                    #region BodyParts
                    //Bodyparts
                    MDL_Bodyparts = new StudioBodyPart[MDL_Header.bodypart_count];
                    for (Int32 BodypartID = 0; BodypartID < MDL_Header.bodypart_count; BodypartID++)
                    {
                        mstudiobodyparts_t BodyPart = new mstudiobodyparts_t();
                        Int32 BodyPartOffset = MDL_Header.bodypart_offset + (16 * BodypartID);
                        FileStream.ReadTypeFixed(ref BodyPart, 16, BodyPartOffset);

                        if (BodyPart.sznameindex != 0)
                            MDL_Bodyparts[BodypartID].Name = FileStream.ReadNullTerminatedString(BodyPartOffset + BodyPart.sznameindex);
                        else
                            MDL_Bodyparts[BodypartID].Name = String.Empty;

                        MDL_Bodyparts[BodypartID].Models = new StudioModel[BodyPart.nummodels];

                        for (Int32 ModelID = 0; ModelID < BodyPart.nummodels; ModelID++)
                        {
                            mstudiomodel_t Model = new mstudiomodel_t();
                            Int64 ModelOffset = BodyPartOffset + (148 * ModelID) + BodyPart.modelindex;
                            FileStream.ReadTypeFixed(ref Model, 148, ModelOffset);

                            MDL_Bodyparts[BodypartID].Models[ModelID].isBlank = (Model.numvertices <= 0 || Model.nummeshes <= 0);
                            MDL_Bodyparts[BodypartID].Models[ModelID].Model = Model;

                            MDL_Bodyparts[BodypartID].Models[ModelID].Meshes = new mstudiomesh_t[Model.nummeshes];
                            for (Int32 MeshID = 0; MeshID < Model.nummeshes; MeshID++)
                            {
                                mstudiomesh_t Mesh = new mstudiomesh_t();
                                Int64 MeshOffset = ModelOffset + (116 * MeshID) + Model.meshindex;
                                FileStream.ReadTypeFixed(ref Mesh, 116, MeshOffset);

                                MDL_Bodyparts[BodypartID].Models[ModelID].Meshes[MeshID] = Mesh;
                            }

                            MDL_Bodyparts[BodypartID].Models[ModelID].IndicesPerLod = new Dictionary<Int32, List<Int32>>[8];

                            for (Int32 i = 0; i < 8; i++)
                                MDL_Bodyparts[BodypartID].Models[ModelID].IndicesPerLod[i] = new Dictionary<Int32, List<Int32>>();

                            MDL_Bodyparts[BodypartID].Models[ModelID].VerticesPerLod = new mstudiovertex_t[8][];
                        }
                    }
                    //BodyParts
                    #endregion
                }
            }
        }



        public static void PlaySound(MDL_Event mdlEvent)
        {
            if (MDL_Event.parameters.TryGetValue("soundName", out var soundName))
            {
                Debug.Log($"Playing sound '{soundName}' as part of event '{MDL_Event.eventname}'");

                // Assuming a sound manager handles audio playback
                SoundManager soundManager = GameObject.FindFirstObjectByType<SoundManager>();
                if (soundManager != null)
                {
                    soundManager.PlaySound(soundName);
                    Debug.Log($"Sound '{soundName}' successfully played.");
                }
                else
                {
                }
            }
            else
            {
            }
        }

        private void SpawnObject(MDL_Event mdlEvent)
        {
            if (MDL_Event.parameters.TryGetValue("prefabName", out var prefabName) &&
                MDL_Event.parameters.TryGetValue("spawnPosition", out var spawnPositionString))
            {
                Debug.Log($"Spawning object '{prefabName}' at position '{spawnPositionString}' as part of event '{MDL_Event.eventname}'");

                // Convert position string to Vector3
                if (TryParseVector3(spawnPositionString, out Vector3 spawnPosition))
                {
                    // Load the prefab (assuming a resource manager handles loading prefabs by name)
                    GameObject prefab = ResourceManager.LoadPrefab(prefabName);
                    if (prefab != null)
                    {
                        GameObject.Instantiate(prefab, spawnPosition, Quaternion.identity);
                        Debug.Log($"Object '{prefabName}' successfully spawned at {spawnPosition}.");
                    }
                    else
                    {
                    }
                }
                else
                {
                }
            }
            else
            {
            }
        }

        public static bool TryParseVector3(string vectorString, out Vector3 result)
        {
            result = Vector3.zero;

            // Expecting the format "(x,y,z)"
            vectorString = vectorString.Trim('(', ')');
            string[] components = vectorString.Split(',');

            if (components.Length == 3 &&
                float.TryParse(components[0], out float x) &&
                float.TryParse(components[1], out float y) &&
                float.TryParse(components[2], out float z))
            {
                result = new Vector3(x, y, z);
                return true;
            }

            return false;
        }


        public void SetIndices(Int32 BodypartID, Int32 ModelID, Int32 LODID, Int32 MeshID, List<Int32> Indices)
        {
            MDL_Bodyparts[BodypartID].Models[ModelID].IndicesPerLod[LODID].Add(MeshID, Indices);
        }

        public void SetVertices(Int32 BodypartID, Int32 ModelID, Int32 LODID, Int32 TotalVerts, Int32 StartIndex, mstudiovertex_t[] Vertexes)
        {
            MDL_Bodyparts[BodypartID].Models[ModelID].VerticesPerLod[LODID] = new mstudiovertex_t[TotalVerts];
            Array.Copy(Vertexes, StartIndex, MDL_Bodyparts[BodypartID].Models[ModelID].VerticesPerLod[LODID], 0, TotalVerts);
        }

        public Boolean BuildMesh = true;

        public struct FlexVertex
        {
            public int VertexIndex;           // Index of the vertex this flex applies to
            public Vector3 PositionDelta;     // Change in position for the vertex
            public Vector3 NormalDelta;       // Change in normal for the vertex
            public Vector3 TangentDelta;      // Change in tangent for the vertex

            public static FlexVertex FromReader(BinaryReader reader)
            {
                return new FlexVertex
                {
                    VertexIndex = reader.ReadInt32(),
                    PositionDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle()),
                    NormalDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle()),
                    TangentDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle())
                };
            }
        }


        public FlexVertex[] FlexVertices;
        public byte[] mdldata;
        public byte bone_ { get; private set; }
        public byte flags { get; private set; }
        public int numFrames { get; private set; }
        public Transform transform { get; private set; }
        public GameObject go { get; private set; }
        public Animator animation { get; private set; }
        public byte[] mdlData { get; private set; }

        public Transform BuildModel(Boolean GenerateUV2 = false)
        {
            GameObject ModelObject = new GameObject(MDL_Header.Name);

            #region Bones
            Transform[] Bones = new Transform[MDL_Header.bone_count];
            Dictionary<Int32, String> bonePathDict = new Dictionary<Int32, String>();
            for (Int32 boneID = 0; boneID < MDL_Header.bone_count; boneID++)
            {
                GameObject BoneObject = new GameObject(MDL_BoneNames[boneID]);

                Bones[boneID] = BoneObject.transform;//MDL_Bones.Add(BoneObject.transform);

                Vector3 pos = MDL_StudioBones[boneID].pos * uLoader.UnitScale;
                Vector3 rot = MDL_StudioBones[boneID].rot * Mathf.Rad2Deg;

                //Invert x for convert right-handed to left-handed
                pos.x = -pos.x;

                if (MDL_StudioBones[boneID].parent >= 0)
                {
                    Bones[boneID].parent = Bones[MDL_StudioBones[boneID].parent];
                }
                else
                {
                    float temp = pos.y;
                    pos.y = pos.z;
                    pos.z = -temp;

                    Bones[boneID].parent = ModelObject.transform;
                }

                Bones[boneID].localPosition = pos;
                Bones[boneID].localRotation = (MDL_StudioBones[boneID].parent == -1) ?
                    Quaternion.Euler(-90, 90, -90) * MathLibrary.AngleQuaternion(rot) :
                    MathLibrary.AngleQuaternion(rot);

                bonePathDict.Add(boneID, Bones[boneID].GetTransformPath(ModelObject.transform));
            }

            if (uLoader.DrawArmature)
            {
                MDLArmatureInfo DebugArmature = ModelObject.AddComponent<MDLArmatureInfo>();
                DebugArmature.boneNodes = Bones;
            }
            #endregion

            #region Hitboxes
            if (MDL_Hitboxsets != null)
            {
                for (Int32 HitboxsetID = 0; HitboxsetID < MDL_Header.hitbox_count; HitboxsetID++)
                {
                    for (Int32 HitboxID = 0; HitboxID < MDL_Hitboxsets[HitboxsetID].numhitboxes; HitboxID++)
                    {
                        mstudiobbox_t Hitbox = Hitboxes[HitboxsetID][HitboxID].BBox;
                        BoxCollider BBox = new GameObject(String.Format("Hitbox_{0}", Bones[Hitbox.bone].name)).AddComponent<BoxCollider>();

                        BBox.size = MathLibrary.NegateX(Hitbox.bbmax - Hitbox.bbmin) * uLoader.UnitScale;
                        BBox.center = (MathLibrary.NegateX(Hitbox.bbmax + Hitbox.bbmin) / 2) * uLoader.UnitScale;

                        BBox.transform.parent = Bones[Hitbox.bone];
                        BBox.transform.localPosition = Vector3.zero;
                        BBox.transform.localRotation = Quaternion.identity;

                        //bbox.transform.tag = HitTagType(MDL_BBoxes[i].group);
                    }
                }
            }
            #endregion

            if (BuildMesh)
            {
                for (Int32 BodypartID = 0; BodypartID < MDL_Header.bodypart_count; BodypartID++)
                {
                    StudioBodyPart BodyPart = MDL_Bodyparts[BodypartID];

                    for (Int32 ModelID = 0; ModelID < BodyPart.Models.Length; ModelID++)
                    {
                        StudioModel Model = BodyPart.Models[ModelID];

                        //Skip if model is blank
                        if (Model.isBlank)
                            continue;

                        // Code section handling VTXStripGroup and VTXStrip functionality. Stripped unused vertexes based on LOD level.
                        mstudiovertex_t[] Vertexes = Model.VerticesPerLod[0];

                        BoneWeight[] BoneWeight = new BoneWeight[Vertexes.Length];
                        Vector3[] Vertices = new Vector3[Vertexes.Length];
                        Vector3[] Normals = new Vector3[Vertexes.Length];
                        Vector2[] UvBuffer = new Vector2[Vertexes.Length];

                        for (Int32 i = 0; i < Vertexes.Length; i++)
                        {
                            Vertices[i] = MathLibrary.SwapZY(Vertexes[i].m_vecPosition * uLoader.UnitScale);
                            Normals[i] = MathLibrary.SwapZY(Vertexes[i].m_vecNormal);

                            Vector2 UV = Vertexes[i].m_vecTexCoord;
                            if (uLoader.SaveAssetsToUnity && uLoader.ExportTextureAsPNG)
                                UV.y = -UV.y;

                            UvBuffer[i] = UV;
                            BoneWeight[i] = GetBoneWeight(Vertexes[i].m_BoneWeights);
                        }
                        #endregion

                        #region LOD Support
                        Boolean DetailModeEnabled =
                            uLoader.DetailMode == DetailMode.Lowest ||
                            uLoader.DetailMode == DetailMode.Low ||
                            uLoader.DetailMode == DetailMode.Medium ||
                            uLoader.DetailMode == DetailMode.High;

                        Boolean LODExist = uLoader.EnableLODParsing && !DetailModeEnabled && Model.NumLODs > 1;
                        Transform FirstLODObject = null;
                        LODGroup LODGroup = null;
                        LOD[] LODs = null;
                        Single MaxSwitchPoint = 100;
                        Int32 StartLODIndex = 0;

                        if (LODExist)
                        {
                            LODs = new LOD[Model.NumLODs];

                            for (Int32 LODID = 1; LODID < 3; LODID++)
                            {
                                Int32 LastID = Model.NumLODs - LODID;
                                ModelLODHeader_t LOD = Model.LODData[LastID];

                                //ignore $shadowlod
                                if (LOD.switchPoint != -1)
                                {
                                    if (LOD.switchPoint > 0)
                                        MaxSwitchPoint = LOD.switchPoint;

                                    //Set switchPoint from MaxSwitchPoint (if switchPoint is zero or negative)
                                    if (LODID == 2 || LOD.switchPoint == 0)
                                    {
                                        MaxSwitchPoint += MaxSwitchPoint * uLoader.NegativeAddLODPrecent;
                                        Model.LODData[LOD.switchPoint == 0 ? LastID : LastID + 1].switchPoint = MaxSwitchPoint;
                                    }

                                    // + Threshold used to avoid errors with LODGroup
                                    MaxSwitchPoint += uLoader.ThresholdMaxSwitch;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            if (!uLoader.EnableLODParsing)
                                Model.NumLODs = 1;
                        }

                        if (uLoader.EnableLODParsing && DetailModeEnabled)
                        {
                            StartLODIndex =
                                uLoader.DetailMode == DetailMode.Lowest ? (Model.NumLODs - 1) :
                                uLoader.DetailMode == DetailMode.Low ? (Int32)(Model.NumLODs / 1.5f) :
                                uLoader.DetailMode == DetailMode.Medium ? (Model.NumLODs / 2) : (Int32)(Model.NumLODs / 2.5f);
                        }
                        #endregion

                        #region Build Meshes
                        for (Int32 LODID = StartLODIndex; LODID < Model.NumLODs; LODID++)
                        {
                            #region TODO: Uncomment after find way to strip unused vertexes for lod's (VTXStripGroup / VTXStrip)
                            /*mstudiovertex_t[] Vertexes = Model.VerticesPerLod[LODID];

                            BoneWeight[] BoneWeight = new BoneWeight[Vertexes.Length];
                            Vector3[] Vertices = new Vector3[Vertexes.Length];
                            Vector3[] Normals = new Vector3[Vertexes.Length];
                            Vector2[] UvBuffer = new Vector2[Vertexes.Length];

                            for (Int32 i = 0; i < Vertexes.Length; i++)
                            {
                                Vertices[i] = MathLibrary.SwapZY(Vertexes[i].m_vecPosition * uLoader.UnitScale);
                                Normals[i] = MathLibrary.SwapZY(Vertexes[i].m_vecNormal);

                                Vector2 UV = Vertexes[i].m_vecTexCoord;
                                if (uLoader.SaveAssetsToUnity && uLoader.ExportTextureAsPNG)
                                    UV.y = -UV.y;

                                UvBuffer[i] = UV;
                                BoneWeight[i] = GetBoneWeight(Vertexes[i].m_BoneWeights);
                            }*/
                            #endregion

                            #region LOD
                            ModelLODHeader_t ModelLOD = Model.LODData[LODID];

                            if (LODExist)
                            {
                                if (ModelLOD.switchPoint == 0)
                                    ModelLOD.switchPoint = MaxSwitchPoint;
                                else
                                    ModelLOD.switchPoint = MaxSwitchPoint - ModelLOD.switchPoint;

                                ModelLOD.switchPoint -= ModelLOD.switchPoint * uLoader.SubstractLODPrecent;
                            }
                            #endregion

                            #region Mesh
                            //Create empty object for mesh
                            GameObject MeshObject = new GameObject(Model.Model.Name);
                            MeshObject.name += "_vLOD" + LODID;
                            MeshObject.transform.parent = ModelObject.transform;

                            //Create empty mesh and fill parsed data
                            Mesh Mesh = new Mesh
                            {
                                name = MeshObject.name,

                                subMeshCount = Model.Model.nummeshes,
                                vertices = Vertices
                            };
                            //Make sure if mesh exist any vertexes
                            if (Mesh.vertexCount <= 0)
                            {
                                continue;
                            }

                            Mesh.normals = Normals;
                            Mesh.uv = UvBuffer;
                            #endregion

                            #region Renderers
                            Renderer Renderer;
                            //SkinnedMeshRenderer (Models with "animated" bones & skin data)
                            if (!MDL_Header.flags.HasFlag(StudioHDRFlags.STUDIOHDR_FLAGS_STATIC_PROP))
                            {
                                //Bind poses & bone weights
                                SkinnedMeshRenderer SkinnedRenderer = MeshObject.AddComponent<SkinnedMeshRenderer>();
                                Renderer = SkinnedRenderer;
                                Matrix4x4[] BindPoses = new Matrix4x4[Bones.Length];

                                for (Int32 i = 0; i < BindPoses.Length; i++)
                                    BindPoses[i] = Bones[i].worldToLocalMatrix * MeshObject.transform.localToWorldMatrix;

                                Mesh.boneWeights = BoneWeight;
                                Mesh.bindposes = BindPoses;

                                SkinnedRenderer.sharedMesh = Mesh;

                                SkinnedRenderer.bones = Bones;
                                SkinnedRenderer.updateWhenOffscreen = true;


                            }
                            //MeshRenderer (models with "STUDIOHDR_FLAGS_STATIC_PROP" flag or with generic "static_prop" bone)
                            else
                            {
                                MeshFilter MeshFilter = MeshObject.AddComponent<MeshFilter>();
                                Renderer = MeshObject.AddComponent<MeshRenderer>();
                                MeshFilter.sharedMesh = Mesh;
                            }

                            Renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.TwoSided;
                            #endregion

                            #region Debug Stuff
#if UNITY_EDITOR
                            DebugMaterial DebugMat = null;
                            if (uLoader.DebugMaterials)
                                DebugMat = MeshObject.AddComponent<DebugMaterial>();
#endif
                            #endregion

                            #region Triangles and Materials
                            Material[] Materials = new Material[Mesh.subMeshCount];

                            for (Int32 MeshID = 0; MeshID < Model.Model.nummeshes; MeshID++)
                            {
                                //Set triangles per lod & submeshes
                                Mesh.SetTriangles(Model.IndicesPerLod[LODID][MeshID], MeshID);

                                //Find & parse materials
                                String MaterialPath;
                                Int32 LastDirID = MDL_TDirectories.Length - 1;
                                for (Int32 DirID = 0; DirID < MDL_TDirectories.Length; DirID++)
                                {
                                    MaterialPath = MDL_TDirectories[DirID] + MDL_Textures[Model.Meshes[MeshID].material];

                                    //If material exist
                                    if (uResourceManager.ContainsFile(MaterialPath, uResourceManager.MaterialsSubFolder, uResourceManager.MaterialsExtension[0]))
                                    {
                                        VMTFile VMT = uResourceManager.LoadMaterial(MaterialPath);

                                        #region Debug Stuff
#if UNITY_EDITOR
                                        if (uLoader.DebugMaterials)
                                            DebugMat.Init(VMT);
#endif
                                        #endregion

                                        //Set material
                                        Materials[MeshID] = VMT.Material;
                                        break;
                                    }
                                    else if (DirID == LastDirID)
                                        Materials[MeshID] = uResourceManager.LoadMaterial(String.Empty).Material;
                                }
                            }

                            Renderer.sharedMaterials = Materials;


                            #endregion

                            #region UV2
#if UNITY_EDITOR
                            if (GenerateUV2)
                            {
                                UnityEditor.SerializedObject so = new UnityEditor.SerializedObject(Renderer);
                                so.FindProperty("m_ScaleInLightmap").floatValue = uLoader.ModelsLightmapSize;
                                so.ApplyModifiedProperties();

                                MeshObject.isStatic = GenerateUV2;
                                uResourceManager.UV2GenerateCache.Add(Mesh);
                            }
#endif
                            #endregion

                            #region Set LOD's
                            if (LODExist)
                            {
                                if (LODID == 0)
                                {
                                    LODGroup = MeshObject.AddComponent<LODGroup>();
                                    FirstLODObject = MeshObject.transform;
                                }
                                else if (FirstLODObject != null)
                                    MeshObject.transform.parent = FirstLODObject;

                                LODs[LODID] = new LOD(ModelLOD.switchPoint / MaxSwitchPoint, new Renderer[] { Renderer });
                            }

                            if (uLoader.EnableLODParsing && DetailModeEnabled)
                                break;
                            #endregion
                        }//lod's per model

                        //Init all parsed lod's into LODGroup
                        if (LODGroup != null)
                            LODGroup.SetLODs(LODs);
                        #endregion
                    }//models in bodypart
                }//Bodypart
            }
            #endregion

            ApplyJiggleBones(ModelObject);


            #region Animators
            #region Animators
            if (MDL_SeqDescriptions != null && MDL_SeqDescriptions.Length > 0)
            {
                if (Sequences == null || Sequences.Length == 0)
                {

                    return transform;
                }

                var AnimatorComponent = ModelObject.GetComponent<Animator>();
                if (AnimatorComponent == null)
                {

                    AnimatorComponent = ModelObject.AddComponent<Animator>();
                }

                for (int seqID = 0; seqID < MDL_SeqDescriptions.Length; seqID++)
                {
                    if (Sequences == null || Sequences[seqID].ani == null || Sequences[seqID].ani.Count == 0)
                    {

                        continue;
                    }

                    SeqInfo Sequence = Sequences[seqID];
                    foreach (var animation in Sequence.ani)
                    {
                        if (animation.clip == null)
                        {

                            continue;
                        }

                        // Validate MDL_Header
                        if (MDL_Header.id == 0 || MDL_Header.bone_count <= 0)
                        {

                            return transform;
                        }

                        // Create and initialize AnimationCurves for each bone
                        AnimationCurve[] posX = new AnimationCurve[MDL_Header.bone_count];
                        AnimationCurve[] posY = new AnimationCurve[MDL_Header.bone_count];
                        AnimationCurve[] posZ = new AnimationCurve[MDL_Header.bone_count];
                        AnimationCurve[] rotX = new AnimationCurve[MDL_Header.bone_count];
                        AnimationCurve[] rotY = new AnimationCurve[MDL_Header.bone_count];
                        AnimationCurve[] rotZ = new AnimationCurve[MDL_Header.bone_count];
                        AnimationCurve[] rotW = new AnimationCurve[MDL_Header.bone_count];

                        for (int boneIndex = 0; boneIndex < MDL_Header.bone_count; boneIndex++)
                        {
                            posX[boneIndex] = new AnimationCurve();
                            posY[boneIndex] = new AnimationCurve();
                            posZ[boneIndex] = new AnimationCurve();

                            rotX[boneIndex] = new AnimationCurve();
                            rotY[boneIndex] = new AnimationCurve();
                            rotZ[boneIndex] = new AnimationCurve();
                            rotW[boneIndex] = new AnimationCurve();
                        }

                        // Validate and set numFrames
                        if (numFrames <= 0)
                        {

                            numFrames = 2;
                        }

                        // Create a new animation clip
                        AnimationClip clip = new AnimationClip
                        {
                            name = $"{Sequence.name}_{animation.name}",
                            legacy = true // Set legacy mode if required by your system
                        };

                        for (int frameIndex = 0; frameIndex < numFrames; frameIndex++)
                        {
                            float time = frameIndex / 30.0f; // Assuming 30 FPS for frame timing
                            for (int boneIndex = 0; boneIndex < MDL_Header.bone_count; boneIndex++)
                            {
                                // Validate bone path
                                if (bonePathDict == null || !bonePathDict.ContainsKey(boneIndex))
                                {

                                    continue;
                                }

                                // Apply position curves
                                clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localPosition.x", posX[boneIndex]);
                                clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localPosition.y", posY[boneIndex]);
                                clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localPosition.z", posZ[boneIndex]);

                                // Apply rotation curves
                                clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localRotation.x", rotX[boneIndex]);
                                clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localRotation.y", rotY[boneIndex]);
                                clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localRotation.z", rotZ[boneIndex]);
                                clip.SetCurve(bonePathDict[boneIndex], typeof(Transform), "localRotation.w", rotW[boneIndex]);
                            }
                        }

                        // Ensure quaternion continuity for smooth transitions
                        clip.EnsureQuaternionContinuity();

                        Debug.Log($"Added animation clip: {clip.name}");
                    }
                }

                #endregion

                #endregion


                InitializeAnimatorComponent(ModelObject);
                AssignAnimationClips();
                // Automatyczne zastosowanie ruchu oczu (jeśli istnieje target kamery)
                ProcessModel(ModelObject);
                // At the end of BuildModel or wherever the model is ready for animations
                InitializeAnimatorSystem(ModelObject);
                ProcessFlexes(ModelObject);

                ApplyEyeMovement(ModelObject);
                ParseSequences(new uReader(fileStream));
                AssignAnimationsToAnimator(ModelObject);

            }


            //If model has compiled flag "$staticprop"
            //then rotate this model by 90 degrees (Y)
            //https://github.com/ValveSoftware/source-sdk-2013/blob/master/sp/src/public/studio.h#L1965
            //Big thanks for this tip: 
            //ShadelessFox
            //REDxEYE
            if (MDL_Header.flags.HasFlag(StudioHDRFlags.STUDIOHDR_FLAGS_STATIC_PROP))
                ModelObject.transform.eulerAngles = new Vector3(0, 90, 0);

            return ModelObject.transform;
        }
        public enum EventType { PlaySound, SpawnObject, StartAnimator }

        /// <summary>
        /// Validates whether the given offset is within the bounds of the stream.
        /// </summary>
        /// <param name="offset">Offset to validate.</param>
        /// <param name="stream">Stream to validate against.</param>
        /// <param name="errorMessage">Custom error message in case of invalid offset.</param>
        /// <param name="errorMessage">Custom error message in case of invalid offset.</param>
        private void TriggerEvent(int eventIndex)
        {
            if (MDL_Events == null || eventIndex < 0 || eventIndex >= MDL_Events.Length)
            {
                return;
            }

            MDL_Event mdlEvent = new MDL_Event("eventname", 1);
            Debug.Log($"Event triggered: {MDL_Event.eventname} on frame {MDL_Event.frame}");

            if (Enum.TryParse(MDL_Event.eventname, ignoreCase: true, out EventType eventType))
            {
                switch (eventType)
                {
                    case EventType.PlaySound:
                        PlaySound(mdlEvent);
                        break;

                    case EventType.SpawnObject:
                        SpawnObject(mdlEvent);
                        break;

                    case EventType.StartAnimator:
                        StartAnimator(mdlEvent);
                        break;

                    default:
                        break;
                }
            }
            else
            {
            }
        }
        Animator animator;
        private int eventsCount;
#if UNITY_EDITOR 

        private AnimatorController animatorcontroller;

#endif
        private AnimationCurve blendCurve;

        private void StartAnimator(MDL_Event mdlEvent)
        {
            if (MDL_Event.parameters.TryGetValue("animationName", out var animationName))
            {
                Debug.Log($"Starting animation '{animationName}' as part of event '{MDL_Event.eventname}'");

                // Assuming there's a reference to an Animator component

                if (animator == null && go.TryGetComponent<Animator>(out animator))
                    animator.Play(animationName);





                else
                {
                }
            }
            else
            {
            }
        }
        private void ProcessFlexes(GameObject modelObject)
        {
            Debug.Log("Processing flexes...");

            // Ensure the model has a SkinnedMeshRenderer
            SkinnedMeshRenderer skinnedMeshRenderer = modelObject.GetComponent<SkinnedMeshRenderer>();
            if (skinnedMeshRenderer == null || skinnedMeshRenderer.sharedMesh == null)
            {
                Debug.LogError("SkinnedMeshRenderer or mesh is missing!");
                return;
            }

            Mesh mesh = skinnedMeshRenderer.sharedMesh;

            if (MDL_FlexDescs == null || MDL_Flexes == null || FlexVertices == null)
            {
                Debug.LogError("Flex data is invalid or missing.");
                return;
            }

            Debug.Log($"Adding blendshapes for {MDL_FlexDescs.Length} flexes...");
            AddBlendshapes(mesh, MDL_FlexDescs, MDL_Flexes, FlexVertices);
            Debug.Log("Flexes processed successfully.");
        }

        private void AddBlendshapes(Mesh mesh, mstudioflexdesc_t[] flexDescs, mstudioflex_t[] flexes, FlexVertex[] flexVertices)
        {
            HashSet<string> blendshapeNames = new HashSet<string>();

            Vector3[] deltaVertices = new Vector3[mesh.vertexCount];
            Vector3[] deltaNormals = new Vector3[mesh.vertexCount];
            Vector3[] deltaTangents = new Vector3[mesh.vertexCount];

            foreach (var flex in flexes)
            {
                if (!ValidateFlexData(flex, mesh.vertexCount, flexVertices.Length))
                {
                    Debug.LogWarning($"Skipping invalid flex at vertex offset {flex.vertexOffset}");
                    continue;
                }

                // Clear deltas for this flex
                Array.Clear(deltaVertices, 0, deltaVertices.Length);
                Array.Clear(deltaNormals, 0, deltaNormals.Length);

                // Apply deltas
                for (int i = 0; i < flex.numVerts; i++)
                {
                    int vertexIndex = flex.vertexOffset + i;
                    if (vertexIndex >= flexVertices.Length) continue;

                    var flexVertex = flexVertices[vertexIndex];
                    if (flexVertex.VertexIndex >= deltaVertices.Length) continue;

                    deltaVertices[flexVertex.VertexIndex] = flexVertex.PositionDelta;
                    deltaNormals[flexVertex.VertexIndex] = flexVertex.NormalDelta;
                }

                // Get flex name
                string flexName = flexDescs[flex.flexDesc].pszFACS(mdlData, 0) ?? $"BlendShape_{flex.flexDesc}";
                if (!blendshapeNames.Add(flexName))
                {
                    Debug.LogWarning($"Duplicate blendshape skipped: {flexName}");
                    continue;
                }

                // Add the blendshape frame to the mesh
                mesh.AddBlendShapeFrame(flexName, 100f, deltaVertices, deltaNormals, deltaTangents);
                Debug.Log($"Blendshape added: {flexName}");
            }

            mesh.RecalculateBounds();
            Debug.Log("Blendshape creation completed.");
        }

        private bool ValidateFlexData(mstudioflex_t flex, int vertexCount, int flexVertexLength)
        {
            return !(flex.numVerts > vertexCount || flex.vertexOffset + flex.numVerts > flexVertexLength);
        }

        private void ParseSequences(uReader fileStream)
        {
            Debug.Log("Parsing sequences...");
            Sequences = new SeqInfo[MDL_Header.localseq_count];
            for (int seqID = 0; seqID < MDL_Header.localseq_count; seqID++)
            {
                int seqOffset = MDL_Header.localseq_offset + (212 * seqID);
                fileStream.ReadTypeFixed(ref sequence, 212, seqOffset);

                // Inicjalizacja groupsize (domyślne wartości 1x1, jeśli brak danych)
                if (sequence.groupsize == null || sequence.groupsize.Length < 2)
                {
                    sequence.groupsize = new int[] { 1, 1 };
                }

                // Wypełnienie Sequence
                Sequences[seqID] = new SeqInfo
                {
                    name = fileStream.ReadNullTerminatedString(seqOffset + sequence.szlabelindex),
                    seq = sequence,
                    ani = new List<AniInfo>()
                };
            

            Debug.Log($"Sequence loaded: {Sequences[seqID].name}");

                // Parse animations for this sequence
                ParseAnimationsForSequence(fileStream, sequence, Sequences[seqID]);
            }
        }
        private void ParseAnimationsForSequence(uReader fileStream, mstudioseqdesc_t sequence, SeqInfo sequenceInfo)
        {
            int animGroupSize = sequence.groupsize[0] * sequence.groupsize[1];
            byte[] animIndices = new byte[animGroupSize];

            // Validate animindexindex
            if (sequence.animindexindex < 0 || sequence.animindexindex >= fileStream.BaseStream.Length)
            {
                Debug.LogError("Invalid animindexindex in sequence.");
                return;
            }

            // Read animation indices
            fileStream.BaseStream.Position = sequence.animindexindex;
            fileStream.Read(animIndices, 0, animIndices.Length);

            // Ensure sequenceInfo.ani is initialized
            if (sequenceInfo.ani == null)
            {
                sequenceInfo.ani = new List<AniInfo>();
            }

            foreach (var animIndex in animIndices)
            {
                // Validate animIndex
                if (Animators == null || animIndex < 0 || animIndex >= Animators.Count)
                {
                    Debug.LogError("Invalid animIndex or Animators list is null.");
                    return;
                }


                // Get AniInfo and validate
                AniInfo aniInfo = Animators[animIndex];
                if (aniInfo == null)
                {
                    Debug.LogWarning($"Animator at index {animIndex} is null.");
                    continue;
                }

                // Add AniInfo to sequenceInfo
                sequenceInfo.ani.Add(aniInfo);
                Debug.Log($"Added animation: {aniInfo.name} to sequence: {sequenceInfo.name}");
            }
        }


        private void AssignAnimationsToAnimator(GameObject modelObject)
        {
            Animator animator = modelObject.GetComponent<Animator>();
            if (animator == null) animator = modelObject.AddComponent<Animator>();

            AnimatorOverrideController overrideController = new AnimatorOverrideController();
            overrideController.runtimeAnimatorController = animator.runtimeAnimatorController;

            foreach (var sequence in Sequences)
            {
                foreach (var animation in sequence.ani)
                {
                    if (animation.clip != null)
                    {
                        string stateName = $"{sequence.name}_{animation.name}";
                        overrideController[stateName] = animation.clip;
                        Debug.Log($"Assigned AnimationClip: {animation.clip.name} to state: {stateName}");
                    }
                }
            }

            animator.runtimeAnimatorController = overrideController;
            Debug.Log("Animator setup complete with all sequences.");
        }

        public class SMDLoader
        {
            public static Dictionary<int, Dictionary<string, BoneFrameData>> BoneFrameDataPerFrame = new Dictionary<int, Dictionary<string, BoneFrameData>>();

            // Data structure to hold bone data for each frame
            public class BoneFrameData
            {
                public Vector3 Position;
                public Quaternion Rotation;

                public BoneFrameData(Vector3 position, Quaternion rotation)
                {
                    Position = position;
                    Rotation = rotation;
                }
            }


            // Ensuring LoadSMDAnimators is used

            public static void LoadSMDAnimators(string smdFilePath)
            {
                StreamReader reader = new(Stream.Null);
                int currentFrame = -1;
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line.StartsWith("time"))
                    {
                        currentFrame = int.Parse(line.Split(' ')[1]);
                        BoneFrameDataPerFrame[currentFrame] = new Dictionary<string, BoneFrameData>();
                    }
                    else
                    {
                        // Parse transformations
                        string[] parts = line.Split(' ');
                        if (parts.Length >= 7)
                        {
                            string boneName = parts[0];
                            Vector3 position = new Vector3(float.Parse(parts[1]), float.Parse(parts[2]), float.Parse(parts[3]));
                            Quaternion rotation = new Quaternion(float.Parse(parts[4]), float.Parse(parts[5]), float.Parse(parts[6]), float.Parse(parts[7]));
                            BoneFrameDataPerFrame[currentFrame][boneName] = new BoneFrameData(position, rotation);
                        }
                    }
                }
            }

        }
        public static void Use_LoadSMDAnimators()
        {
            SMDLoader.LoadSMDAnimators("models");

            Use_LoadSMDAnimators();
        }
        [Serializable]
        public class MDL_Event
        {
            // The name of the event
            public static string eventname;

            // The frame or timestamp where this event occurs
            public static int frame;

            // A dictionary to store custom parameters for the event
            public static Dictionary<string, string> parameters;

            // Constructor
            public MDL_Event(string eventname, int frame, Dictionary<string, string> parameters = null)
            {
                MDL_Event.eventname = eventname;
                MDL_Event.frame = frame;
                parameters = parameters ?? new Dictionary<string, string>();
            }

            /// <summary>
            /// Add or update a parameter in the event.
            /// </summary>
            /// 

            // Ensuring AddParameter is used
            public static void Use_AddParameter() { AddParameter("param_1", "1"); }

            // Ensuring TryGetParameter is used

            string value;
            public static void Use_TryGetParameter(MDL_Event mdlEvent)
            {
                if (mdlEvent.TryGetParameter("param_1", out string value))
                {
                    Debug.Log($"Parameter 'param_1' found with value: {value}");
                }
                else
                {
                    Debug.Log("Parameter 'param_1' not found.");
                }
            }
            // Ensuring RemoveParameter is used
            public static void Use_PrintDetails() { PrintDetails(); }
            public static void AddParameter(string key, string value)
            {
                if (parameters.ContainsKey(key))
                {
                    parameters[key] = value;
                    Debug.Log($"Updated parameter '{key}' with value '{value}' for event '{eventname}'.");
                }
                else
                {
                    parameters.Add(key, value);
                    Debug.Log($"Added parameter '{key}' with value '{value}' for event '{eventname}'.");
                }
            }

            /// <summary>
            /// Get a parameter value by key.
            /// Returns true if the key exists, false otherwise.
            /// </summary>
            public bool TryGetParameter(string key, out string value)
            {
                return parameters.TryGetValue(key, out value);
            }

            /// <summary>
            /// Remove a parameter from the event.
            /// </summary>
            /// 

            public static bool RemoveParameter(string key)
            {
                if (parameters.Remove(key))
                {
                    Debug.Log($"Removed parameter '{key}' from event '{eventname}'.");
                    return true;
                }

                return false;
            }

            /// <summary>
            /// Print all event details for debugging.
            /// </summary>
            public static void PrintDetails()
            {
                Debug.Log($"Event Details:\nName: {eventname}\nFrame: {frame}\nParameters:");
                foreach (var parameter in parameters)
                {
                    Debug.Log($"  {parameter.Key}: {parameter.Value}");
                }
            }
        }

        private void InitializeMethods()
        {
            // Sequential initialization of Use_ methods
            Use_HandleSequenceEvents();
            Use_OnTriggerEnter();
            Use_ApplyAnimationClip();
            Use_PopulateKeyframesForAnimator();
            Use_UpdateProceduralBones();
            Use_PlayAnimatorsByCategory();
            Use_AddAllAnimators();
            
            Use_AnimationClipCreator();
            MDL_Event.Use_AddParameter();
          
            MDL_Event.Use_PrintDetails();
            
            JiggleBone.Use_UpdateWindSettings();
            Use_LoadSMDAnimators();
            Use_CreateAnimationClip();
            Use_ProcessFile();
        }

        public static void Use_CreateAnimationClip()
        {
            AnimationClipCreator.CreateAnimationClip(new SMDLoader(), new Transform[0], "", 1);
            Use_CreateAnimationClip();
        }

        public class AnimationClipCreator
        {
            public static AnimationClip CreateAnimationClip(SMDLoader smdLoader, Transform[] boneTransforms, string clipName, float frameRate = 24f)
            {
                AnimationClip clip = new AnimationClip
                {
                    name = clipName,
                    frameRate = frameRate,
                    legacy = true
                };

                foreach (var frameEntry in SMDLoader.BoneFrameDataPerFrame)
                {
                    int frame = frameEntry.Key;
                    float time = frame / frameRate;

                    foreach (var boneData in frameEntry.Value)
                    {
                        string boneName = boneData.Key;
                        SMDLoader.BoneFrameData frameData = boneData.Value;

                        // Apply position curves
                        clip.SetCurve(boneName, typeof(Transform), "localPosition.x", CreateCurve(boneTransforms, boneName, time, frameData.Position.x));
                        clip.SetCurve(boneName, typeof(Transform), "localPosition.y", CreateCurve(boneTransforms, boneName, time, frameData.Position.y));
                        clip.SetCurve(boneName, typeof(Transform), "localPosition.z", CreateCurve(boneTransforms, boneName, time, frameData.Position.z));

                        // Apply rotation curves
                        clip.SetCurve(boneName, typeof(Transform), "localRotation.x", CreateCurve(boneTransforms, boneName, time, frameData.Rotation.x));
                        clip.SetCurve(boneName, typeof(Transform), "localRotation.y", CreateCurve(boneTransforms, boneName, time, frameData.Rotation.y));
                        clip.SetCurve(boneName, typeof(Transform), "localRotation.z", CreateCurve(boneTransforms, boneName, time, frameData.Rotation.z));
                        clip.SetCurve(boneName, typeof(Transform), "localRotation.w", CreateCurve(boneTransforms, boneName, time, frameData.Rotation.w));
                    }
                }

                clip.EnsureQuaternionContinuity();
                return clip;
            }
        }


        private void Use_HandleSequenceEvents()
        {
            HandleSequenceEvents(sequence, 0);
        }



        #region Misc Stuff

        #region Misc Stuff
        static String HitTagType(Int32 typeHit)
        {
            String returnType;
            switch (typeHit)
            {
                case 1: // - Used for human NPC heads and to define where the player sits on the vehicle.mdl, appears Red in HLMV
                    returnType = "Head";
                    break;

                case 2: // - Used for human NPC midsection and chest, appears Green in HLMV
                    returnType = "Chest";
                    break;

                case 3: // - Used for human NPC stomach and pelvis, appears Yellow in HLMV
                    returnType = "Stomach";
                    break;

                case 4: // - Used for human Left Arm, appears Deep Blue in HLMV
                    returnType = "Left_Arm";
                    break;

                case 5: // - Used for human Right Arm, appears Bright Violet in HLMV
                    returnType = "Right_Arm";
                    break;

                case 6: // - Used for human Left Leg, appears Bright Cyan in HLMV
                    returnType = "Left_Leg";
                    break;

                case 7: // - Used for human Right Leg, appears White like the default group in HLMV
                    returnType = "Right_Leg";
                    break;

                case 8: // - Used for human neck (to fix penetration to head from behind), appears Orange in HLMV (in all games since Counter-Strike: Global Offensive)
                    returnType = "Neck";
                    break;

                default: // - the default group of hitboxes, appears White in HLMV
                    returnType = "Generic";
                    break;
            }
            return returnType;
        }


        BoneWeight GetBoneWeight(mstudioboneweight_t mBoneWeight)
        {
            BoneWeight boneWeight = new BoneWeight();

            boneWeight.boneIndex0 = mBoneWeight.bone[0];
            boneWeight.boneIndex1 = mBoneWeight.bone[1];
            boneWeight.boneIndex2 = mBoneWeight.bone[2];

            boneWeight.weight0 = mBoneWeight.weight[0];
            boneWeight.weight1 = mBoneWeight.weight[1];
            boneWeight.weight2 = mBoneWeight.weight[2];

            return boneWeight;
        }

        #endregion

#if UNITY_EDITOR

        public Transform[] BoneTransforms;
        public void BlendAnimators(AnimationClip clip, AnimationClip nextClip, AnimationCurve blendTime)
        {
            AnimatorHelper.BlendAnimationClips(animatorcontroller, clip, nextClip, blendTime, "");

            foreach (Transform bone in BoneTransforms)
            {
                ApplyCurveWithBlend(clip, nextClip, bone.name, blendCurve);
            }
        }
#endif
#if UNITY_EDITOR
        void ApplyCurveWithBlend(AnimationClip clip, AnimationClip nextClip, string boneName, AnimationCurve blendCurve)
        {
            AnimationCurve positionCurveX = AnimatorHelper.AddAnimationClipToController(animatorcontroller, clip, "localPosition.x");
            AnimationCurve positionCurveY = AnimatorHelper.AddAnimationClipToController(animatorcontroller, clip, "localPosition.y");
            AnimationCurve positionCurveZ = AnimatorHelper.AddAnimationClipToController(animatorcontroller, clip, "localPosition.z");

            AnimatorHelper.AddAnimationClipToController(animatorcontroller, nextClip, "localPosition.x");
            AnimatorHelper.AddAnimationClipToController(animatorcontroller, nextClip, "localPosition.y");
            AnimatorHelper.AddAnimationClipToController(animatorcontroller, nextClip, "localPosition.z");

            // Apply blended curves to clip for each positional axis
            clip.SetCurve(boneName, typeof(Transform), "localPosition.x", AnimatorHelper.BlendAnimationClips(animatorcontroller, clip, nextClip, positionCurveX, boneName));
            clip.SetCurve(boneName, typeof(Transform), "localPosition.y", AnimatorHelper.BlendAnimationClips(animatorcontroller, clip, nextClip, positionCurveY, boneName));
            clip.SetCurve(boneName, typeof(Transform), "localPosition.z", AnimatorHelper.BlendAnimationClips(animatorcontroller, clip, nextClip, positionCurveZ, boneName));
        }

#endif
        public List<JiggleBone> JiggleBones;
        private mstudioseqdesc_t sequence;

        public void UpdateProceduralBones(float deltaTime)
        {
            foreach (var jiggleBone in MDL_JiggleBones)
            {
                Transform[] Bones = new Transform[MDL_Header.bone_count];
                Transform bone = Bones[jiggleBone.bone];
                var jiggle = new JiggleBone(bone);
                jiggle.Update(Time.deltaTime, transform.position);
            }

        }
        #region Shape Keys/Blend Shapes for Expressions
        public static void ApplyShapeKeyAnimator(SkinnedMeshRenderer meshRenderer, Flex[] flexes)
        {
            Mesh mesh = meshRenderer.sharedMesh;
            foreach (Flex flex in flexes)
            {
                Vector3[] deltaVertices = new Vector3[mesh.vertexCount];
                Vector3[] deltaNormals = new Vector3[mesh.vertexCount];
                foreach (var anim in flex.VertexAnimations)
                {
                    deltaVertices[anim.Index] = anim.PositionDelta;
                    deltaNormals[anim.Index] = anim.NormalDelta;
                }
                mesh.AddBlendShapeFrame(flex.Name, 100f, deltaVertices, deltaNormals, null);
            }
        }
        #endregion


        public struct PoseParameter
        {
            public string Name;
            public int Index;
            public float MinValue;
            public float MaxValue;
            public float DefaultValue;
            public AnimationCurve Curve;
        }

        PoseParameter[] LoadPoseParameters(uReader fileStream)
        {
            List<PoseParameter> poseParameters = new List<PoseParameter>();

            for (int i = 0; i < MDL_Header.localposeparam_count; i++)
            {
                PoseParameter parameter = new PoseParameter
                {
                    Name = fileStream.ReadNullTerminatedString(),
                    MinValue = fileStream.ReadInt64(),
                    MaxValue = fileStream.ReadInt64(),
                    DefaultValue = fileStream.ReadInt64()
                };
                poseParameters.Add(parameter);
            }

            return poseParameters.ToArray();
        }


        public class VertexAnimator
        {
            public int Index;
            public Vector3 PositionDelta;
            public Vector3 NormalDelta;
            internal static VertexAnimator FromBuffer(BinaryReader reader)
            {
                return new VertexAnimator
                {
                    // Read the Index (int, 4 bytes)
                    Index = reader.ReadInt32(),

                    // Read the PositionDelta (Vector3, 3 floats = 12 bytes)
                    PositionDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle()),

                    // Read the NormalDelta (Vector3, 3 floats = 12 bytes)
                    NormalDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle()),

                    // Read the VertexDelta (Vector3, 3 floats = 12 bytes)
                    VertexDelta = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle())
                };
            }

            public Vector3 VertexDelta { get; internal set; }
        }

        public class Eyeball
        {
            public string Name;
            public int BoneIndex;
            public float Radius;
            public Vector3 Position;
            public string Material;
            public float IrisScale;

            public Texture Texture { get; internal set; }
            public float SpecularIntensity { get; internal set; }
            public float SpecularPower { get; internal set; }
            public float ReflectionIntensity { get; internal set; }
            public Texture ReflectionTexture { get; internal set; }
            public float IrisSize { get; internal set; }
            public Texture IrisTexture { get; internal set; }
            public float PupilOffset { get; internal set; }
            public float PupilScale { get; internal set; }
            public Texture PupilTexture { get; internal set; }
        }
        public class JiggleBone
        {
            public Transform BoneTransform;
            private Vector3 currentPosition;
            private Vector3 velocity;
            private Vector3 acceleration;

            private Vector3 goalPosition; // Resting position
            private Vector3 gravity = new Vector3(0, -9.81f, 0);
            private float gravityScale = 1.0f;

            public float Stiffness = 0.5f;  // How strongly the bone returns to its goal position
            public float Damping = 0.2f;    // How much oscillation is reduced over time
            public float Mass = 1.0f;       // Bone "weight"
            public float Length = 1.0f;     // Max distance allowed from the base position
            private static Stream FileInput;
            private static readonly MDLFile mdlFile;

            public JiggleBone(Transform boneTransform)
            {
                BoneTransform = boneTransform;
                currentPosition = boneTransform.position;
                goalPosition = boneTransform.position;
                velocity = Vector3.zero;
            }

            public void Update(float deltaTime, Vector3 basePosition)
            {
                // Calculate spring force
                Vector3 displacement = goalPosition - currentPosition;
                Vector3 springForce = displacement * Stiffness;

                // Damping force to reduce oscillations
                Vector3 dampingForce = -velocity * Damping;

                // Gravity
                Vector3 gravityForce = gravity * gravityScale;

                // Calculate final acceleration
                acceleration = (springForce + dampingForce + gravityForce) / Mass;

                // Update velocity and position
                velocity += acceleration * deltaTime;
                currentPosition += velocity * deltaTime;

                // Apply length constraint
                Vector3 direction = (currentPosition - basePosition).normalized;
                currentPosition = basePosition + direction * Mathf.Min(Length, Vector3.Distance(currentPosition, basePosition));

                // Apply the new position and smooth rotation
                BoneTransform.position = currentPosition;
                SmoothRotation(basePosition);
            }

            private void SmoothRotation(Vector3 basePosition)
            {
                Vector3 direction = (currentPosition - basePosition).normalized;
                Quaternion targetRotation = Quaternion.LookRotation(direction);
                BoneTransform.rotation = Quaternion.Slerp(BoneTransform.rotation, targetRotation, 0.1f);
            }



            // Utility method to create and assign a default AnimatorController if needed
#if UNITY_EDITOR
            public static RuntimeAnimatorController CreateDefaultAnimatorController(GameObject modelObject, MDLFile mdlFile)
            {
                // Validate input parameters
                if (modelObject == null)
                {
                    throw new ArgumentNullException(nameof(modelObject), "ModelObject cannot be null.");
                }

                if (mdlFile == null || mdlFile.Sequences == null)
                {

                }

                // Ensure the GameObject has an Animator component
                Animator animator = modelObject.GetComponent<Animator>();
                if (animator == null)
                {
                    animator = modelObject.AddComponent<Animator>();
                }

                // Create an AnimatorController
                AnimatorController controller = AnimatorController.CreateAnimatorControllerAtPath("Assets/GeneratedAnimatorController.controller");
                if (controller == null || controller.layers.Length == 0)
                {
                    throw new InvalidOperationException("Failed to create a valid AnimatorController.");
                }

                // Access the state machine
                AnimatorStateMachine stateMachine = controller.layers[0].stateMachine;
                if (stateMachine == null)
                {
                    throw new InvalidOperationException("StateMachine in AnimatorController is not properly initialized.");
                }

                // Iterate over all sequences in the MDL file and add states for each animation
                // Ensure mdlFile is not null
                if (mdlFile == null || mdlFile.Sequences == null)
                {

                }

#endif
                // Method to ensure the Animator is correctly configured

#if UNITY_EDITOR
                // Iterate over all sequences in the MDL file
                if (mdlFile == null)
                {
                    Debug.LogWarning("mdlFile is null, using a default instance");
                    mdlFile = new MDLFile(FileInput, new mstudioevent_t[index]); // Default initialization
                }

                if (stateMachine == null)
                {
                    Debug.LogError("stateMachine is null");
                    return null; // Early exit if stateMachine is not initialized
                }

                // Iterate over all sequences in the MDL file
                foreach (var sequence in mdlFile.Sequences ?? Array.Empty<SeqInfo>())
                {
                    if (sequence.ani == null || sequence.ani.Count == 0)
                    {
                        Debug.LogWarning($"Skipping sequence: {sequence.name ?? "Unnamed"} - ani is null or empty");
                        continue; // Skip null or invalid sequences
                    }

                    var animations = sequence.ani ?? new List<AniInfo>();
                    foreach (var aniInfo in animations)
                    {
                        if (aniInfo?.clip == null)
                        {
                            Debug.LogWarning($"Skipping animation: {aniInfo?.name ?? "Unnamed"} - clip is null");
                            continue; // Skip null or invalid animations
                        }

                        // Process the animation clip
                        string stateName = $"{sequence.name}_{aniInfo.name}";
                        AnimatorState state = stateMachine.AddState(stateName);
                        state.motion = aniInfo.clip; // Assign the animation clip to the state
                        Debug.Log($"Added state: {stateName} with clip: {aniInfo.clip.name}");
                    }
                }


                // Assign the created AnimatorController to the Animator component
                animator.runtimeAnimatorController = controller;

                if (animator == null)
                {
                    Debug.LogError("Animator component is null");
                    return null;
                }

                animator.runtimeAnimatorController = controller;
                Debug.Log("AnimatorController assigned successfully");

                return controller;
            }

            public static void EnsureAnimatorIsPlaying(GameObject modelObject)
            {
                Animator animator = modelObject.GetComponent<Animator>();
                if (animator == null)
                {
                    animator = modelObject.AddComponent<Animator>();
                    Debug.Log("Animator component added to the GameObject.");
                }

                // Assign a default AnimatorController if none exists
                if (animator.runtimeAnimatorController == null)
                {
                    animator.runtimeAnimatorController = CreateDefaultAnimatorController(modelObject, mdlFile);
                    Debug.Log("Assigned a default AnimatorController to the Animator.");
                }

                // Trigger a default animation to ensure the Animator is playing
                if (animator.runtimeAnimatorController is AnimatorController controller && controller.layers.Length > 0)
                {
                    animator.Play(controller.layers[0].stateMachine.defaultState.name);
                    Debug.Log("Animator is now playing the default state.");
                }
                else
                {

                }
            }

#endif
            private void SmoothlyUpdateBoneRotation(Vector3 basePosition, float deltaTime)
            {
                // Calculate target rotation based on direction from base to current position
                Vector3 directionToCurrent = (currentPosition - basePosition).normalized;
                Quaternion targetRotation = Quaternion.LookRotation(directionToCurrent);

                // Interpolate towards target rotation with a rotation speed limit
                float rotationStep = 0 * deltaTime;
                BoneTransform.rotation = Quaternion.RotateTowards(BoneTransform.rotation, targetRotation, rotationStep);

                // Apply rotational damping to prevent excessive rotation oscillations
                BoneTransform.rotation = Quaternion.Slerp(BoneTransform.rotation, targetRotation, Damping * deltaTime);
            }

            // Additional customization methods:

            public static void AdjustLengthBasedOnSpeed(float speed, float minLength, float maxLength)
            {
                // Dynamically adjust the max length based on the speed of the character or object
                minLength = Mathf.Lerp(minLength, maxLength, speed);
            }
            public static void Use_UpdateWindSettings() { UpdateWindSettings(new Vector3(), new float()); }
            public static void UpdateWindSettings(Vector3 newDirection, float newStrength)
            {
                // Allow in-game adjustment of wind direction and strength

            }
        }

        public class EyeballData
        {
            public Vector3 Position;
            public Vector3 UpDirection;
            public Vector3 ForwardDirection;
            public float Radius;
            public float ZOffset;
        }

        public class BoneAnimatorFrame
        {
            public int BoneIndex;
            public Vector3 Position;
            public Quaternion Rotation;

        }


        public GameObject TargetGameObject { get; set; }
        public float positionCurveZ { get; private set; }
        public float positionCurveY { get; private set; }
        public float positionCurveX { get; private set; }
        public List<Animator> AnimComponent { get; private set; }
        public string ForwardDirection { get; private set; }
        public string UpDirection { get; private set; }
        public string ZOffset { get; private set; }
        public string IrisScale { get; private set; }

        public void PlayAnimatorsByCategory(string category)
        {
            foreach (var sequence in Sequences)
            {
                foreach (var animation in sequence.ani)
                {
                    {
                        AnimatorComponent.Play($"{sequence.name}_{animation.name}");
                    }
                }
            }
        }
        private void AddAllAnimators()
        {
            if (AnimatorComponent == null)
            {

                AnimatorComponent = TargetGameObject.AddComponent<Animator>();
            }

            foreach (var sequence in Sequences)
            {
                if (sequence.ani != null)
                {
                    foreach (var animation in sequence.ani)
                    {
                        {
                            AnimatorComponent.GetNextAnimatorClipInfo((int)animation.clip.frameRate);
                            Debug.Log($"Added animation: {animation.Name}");
                        }
                    }
                }
            }
        }


        private Dictionary<string, string> MapAssociatedFiles(string modelName, string directoryPath, string[] fileExtensions)
        {
            var associatedFiles = new Dictionary<string, string>();
            string[] extensions = new[] { ".vta", ".dmx", ".smd" };
            var mappedFiles = MapAssociatedFiles(modelName, directoryPath, extensions);

            foreach (var ext in fileExtensions)
            {
                string searchPattern = $"*{ext}";
                string[] files = Directory.GetFiles(directoryPath, searchPattern);

                foreach (var file in files)
                {
                    string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(file);

                    // Sprawdzanie, czy nazwa modelu jest częścią nazwy pliku
                    if (fileNameWithoutExtension.Contains(modelName, StringComparison.OrdinalIgnoreCase))
                    {
                        associatedFiles[ext] = file;
                        Debug.Log($"Powiązany plik {ext} znaleziony: {file}");


                    }
                }
            }

            return associatedFiles;
        }

        public static string ResolveFileName(string requestedName, Dictionary<string, string> fileMapping)
        {
            foreach (var entry in fileMapping)
            {
                if (requestedName.Contains(entry.Key, StringComparison.OrdinalIgnoreCase))
                {
                    return entry.Value; // Zwraca prawdziwą nazwę pliku
                }
            }

            return requestedName;
        }

        // Example usage of OverrideReferences:
        string modelPath = "path/to/model.mdl";

        // Example usage of OverrideReferences:


        // Ensuring CreateAnimationClip is used

        // Ensuring ProcessFile is used
        private void Use_ProcessFile()
        {
            ProcessFile("models");

            Use_ProcessFile();
        }

        public void ProcessFile(string modelPath)
        {
            using (FileStream stream = new FileStream(modelPath, FileMode.Open))
            {
                MDLFile mdlFile = new MDLFile(stream, null, true, true);
                Dictionary<string, string> fileMapping = MapAssociatedFiles("guard", "path/to/models", new[] { ".vta", ".dmx" });

                OverrideReferences(mdlFile, fileMapping);
                LogModelErrors(mdlFile);
            }
        }

        public void OverrideReferences(MDLFile mdlFile, Dictionary<string, string> fileMapping)
        {
            foreach (var flex in mdlFile.MDL_FlexDescs)
            {
                string oldName = flex.pszFACS(new byte[0], 1);
                string newName = ResolveFileName(oldName, fileMapping);

                Debug.Log($"Podmiana pliku: {oldName} -> {newName}");
                flex.pszFACS(new byte[0], 1);
            }
        }


        public static void LogModelErrors(MDLFile mdlFile)
        {
            if (mdlFile.MDL_Header.id == 0)
            {
            }

            if (mdlFile.MDL_FlexDescs == null || mdlFile.MDL_FlexDescs.Length == 0)
            {
            }

            if (mdlFile.MDL_StudioBones == null || mdlFile.MDL_StudioBones.Length == 0)
            {
            }// Example usage of OverrideReferences:


        }

        private static AnimationCurve CreateCurve(Transform[] bones, string boneName, float time, float value)
        {
            AnimationCurve curve = new AnimationCurve();
            curve.AddKey(new Keyframe(time, value));
            return curve;
        }
    }




}

public class AnimatorManager
{
    private Animator animator;
    private Dictionary<string, AnimationClip> animationClips = new();
    private AnimatorOverrideController overrideController;
    private AnimationClip currentClip;
    private float currentTime;
    public int AnimationClipCount => animationClips.Count;

    public float CurrentTime { get; internal set; }

    public AnimatorManager(GameObject modelObject)
    {
        animator = modelObject.GetComponent<Animator>();
        if (animator == null)
        {
            animator = modelObject.AddComponent<Animator>();
            overrideController = new AnimatorOverrideController();
            animator.runtimeAnimatorController = overrideController;
        }
    }

    public string FirstAnimationName()
    {
        if (animationClips.Count == 0)
        {

            return null;
        }

        // Return the first key from the animationClips dictionary
        return animationClips.Keys.First();
    }

    public void AddAnimationClip(string name, AnimationClip clip)
    {
        if (!animationClips.ContainsKey(name))
        {
            animationClips[name] = clip;
            Debug.Log($"Animation clip {name} added to AnimatorManager.");
        }
    }

    /// <summary>
    /// Assigns all animations to the Animator.
    /// </summary>
    public void UseAllAnims()
    {
        foreach (var clip in animationClips)
        {
            overrideController[clip.Key] = clip.Value;
        }

        Debug.Log($"All {AnimationClipCount} animations assigned to Animator.");
    }


    /// <summary>
    /// Plays an animation clip by name.
    /// </summary>
    public void PlayAnimator(string name, bool loop = false)
    {
        if (animationClips.TryGetValue(name, out AnimationClip clip))
        {
            if (currentClip == clip) return;

            overrideController["BaseAnimator"] = clip;
            animator.Play("BaseAnimator");
            currentClip = clip;
            animator.SetBool("Loop", loop);
            Debug.Log($"Playing animation: {name}");
        }
        else
        {

        }
    }

    /// <summary>
    /// Blends between the current animation and a new one.
    /// </summary>
    public void BlendToAnimator(string name, float blendDuration = 0.5f)
    {
        if (animationClips.TryGetValue(name, out AnimationClip newClip))
        {
            if (currentClip != null && currentClip == newClip)
                return;

            animator.CrossFade(name, blendDuration);
            currentClip = newClip;
            Debug.Log($"Blending to animation: {name}");
        }
        else
        {

        }
    }

    /// <summary>
    /// Stops the current animation.
    /// </summary>
    /// 


    public void StopAnimator()
    {
        animator.StopPlayback();
        currentClip = null;
        Debug.Log("Animator stopped.");
    }

    /// <summary>
    /// Updates the current animation's progress.
    /// </summary>
    public void UpdateAnimator(float deltaTime)
    {
        if (currentClip == null)
            return;

        currentTime += deltaTime;
        float normalizedTime = Mathf.Repeat(currentTime / currentClip.length, 1f);
        animator.Play("BaseAnimator", 0, normalizedTime);
    }
}








#region Bones Setup
#endregion
#endregion

// New Functionality: Loading Animation Clips into Animator Component
public class AnimationLoader
{
    private Animator animator;

    public AnimationLoader(Animator animator)
    {
        this.animator = animator;
    }

    public static MDLFile mdlFile { get; private set; }

    public void LoadAnimationClipsFromMDL(MDLFile mdlFile)
    {
        if (mdlFile?.MDL_SeqDescriptions == null || mdlFile.MDL_SeqDescriptions.Length == 0)
        {

            return;
        }
        AnimatorOverrideController overrideController = new AnimatorOverrideController
        {
            runtimeAnimatorController = animator.runtimeAnimatorController
        };
        animator.runtimeAnimatorController = overrideController;

        foreach (var sequence in mdlFile.MDL_SeqDescriptions)
        {
            string animationName = mdlFile.GetSequenceName(sequence);
            AnimationClip clip = new AnimationClip
            {
                name = animationName,

            };

            // Populate the clip with keyframes (simplified example)
            PopulateKeyframesForSequence(clip, sequence);

            overrideController[animationName] = clip;
            Debug.Log($"Loaded animation clip: {animationName}");
        }
    }
    public static void LoadAnimationsIntoAnimator(GameObject modelObject)
    {
        Animator animator = modelObject.GetComponent<Animator>();
        if (animator == null)
        {
            animator = modelObject.AddComponent<Animator>();
        }

        AnimationLoader loader = new AnimationLoader(animator);
        loader.LoadAnimationClipsFromMDL(mdlFile);
    }
    private void PopulateKeyframesForSequence(AnimationClip clip, mstudioseqdesc_t sequence)
    {
        // Simplified logic for generating keyframes (replace with accurate MDL parsing)
        float frameRate = 30.0f;
        int numFrames = sequence.numblends > 0 ? sequence.numblends : 1;

        for (int frame = 0; frame < numFrames; frame++)
        {
            float time = frame / frameRate;
            Keyframe posX = new Keyframe(time, Mathf.Sin(frame * 0.1f)); // Example sine wave
            AnimationCurve curve = new AnimationCurve(posX);
            clip.SetCurve("", typeof(Transform), "localPosition.x", curve);
        }
    }
}

// Adding a utility method to read sequence names properly


public static class MDLUtilities
{
    public static string GetSequenceName(this MDLFile mdlFile, mstudioseqdesc_t sequence)
    {
        if (sequence.szlabelindex != 0)
        {
            return ReadNullTerminatedString(mdlFile.mdldata, sequence.szlabelindex);
        }
        return "UnnamedAnimation";
    }

    private static string ReadNullTerminatedString(byte[] data, int offset)
    {
        int length = 0;
        while (offset + length < data.Length && data[offset + length] != 0)
        {
            length++;
        }
        return System.Text.Encoding.UTF8.GetString(data, offset, length);
    }
}

//





// VTF to PNG Conversion Logic