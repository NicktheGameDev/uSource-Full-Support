using System;
using System.Text;
using UnityEngine;
using uSource.Formats.Source.MDL;
using static uSource.Formats.Source.MDL.StudioStruct;

namespace uSource.Utilities
{
    public class BlendshapeUtility
    {
        /// <summary>
        /// Adds blendshapes to the provided mesh using MDL flex data.
        /// </summary>
        /// <param name="mesh">The mesh to apply blendshapes to.</param>
        /// <param name="mdlData">Raw MDL file data.</param>
        /// <param name="baseOffset">Base offset for the MDL file's flex data.</param>
        /// <param name="flexDescs">The flex descriptors parsed from the MDL file.</param>
        /// <param name="flexes">The flexes parsed from the MDL file.</param>
        /// <param name="flexVertices">Flex vertex deltas parsed from the MDL file.</param>
        public void AddBlendshapes(
            Mesh mesh,
            byte[] mdlData,
            int baseOffset,
            mstudioflexdesc_t[] flexDescs,
            mstudioflex_t[] flexes,
            MDLFile.FlexVertex[] flexVertices
        )
        {
            if (flexDescs == null || flexes == null || flexVertices == null)
            {
                Debug.LogError("Missing required flex data for blendshape application.");
                return;
            }

            if (mesh == null)
            {
                Debug.LogError("Mesh is null. Cannot apply blendshapes.");
                return;
            }

            if (mdlData == null || mdlData.Length == 0)
            {
                Debug.LogError("MDL data is null or empty. Cannot process blendshapes.");
                return;
            }

            Debug.Log($"Adding blendshapes. Total flexes: {flexes.Length}");

            Vector3[] deltaVertices = new Vector3[mesh.vertexCount];
            Vector3[] deltaNormals = new Vector3[mesh.vertexCount];

            foreach (var flex in flexes)
            {
                if (!ValidateFlexData(flex, mesh.vertexCount, flexVertices.Length))
                {
                    Debug.LogWarning($"Skipping invalid flex: FlexDesc={flex.flexDesc}, NumVerts={flex.numVerts}");
                    continue;
                }

                // Clear deltas for the current blendshape
                Array.Clear(deltaVertices, 0, deltaVertices.Length);
                Array.Clear(deltaNormals, 0, deltaNormals.Length);

                for (int i = 0; i < flex.numVerts; i++)
                {
                    int vertexIndex = flex.vertexOffset + i;
                    if (vertexIndex >= flexVertices.Length || vertexIndex < 0)
                    {
                        Debug.LogWarning($"Vertex index {vertexIndex} out of bounds. Skipping vertex.");
                        continue;
                    }

                    MDLFile.FlexVertex flexVertex = flexVertices[vertexIndex];
                    if (flexVertex.VertexIndex < 0 || flexVertex.VertexIndex >= deltaVertices.Length)
                    {
                        Debug.LogWarning($"Invalid vertex index {flexVertex.VertexIndex}. Skipping vertex.");
                        continue;
                    }

                    deltaVertices[flexVertex.VertexIndex] += flexVertex.PositionDelta;
                    deltaNormals[flexVertex.VertexIndex] += flexVertex.NormalDelta;
                }

                string flexName = flexDescs[flex.flexDesc].pszFACS(mdlData, baseOffset);
                if (string.IsNullOrEmpty(flexName))
                {
                    Debug.LogWarning($"Unable to resolve flex name for FlexDesc {flex.flexDesc}. Skipping.");
                    continue;
                }

                mesh.AddBlendShapeFrame(flexName, 100f, deltaVertices, deltaNormals, null);
                Debug.Log($"Added blendshape: {flexName}");
            }

            Debug.Log("Blendshape application completed.");
        }

        /// <summary>
        /// Validates flex data before applying it to the mesh.
        /// </summary>
        /// <param name="flex">Flex descriptor being validated.</param>
        /// <param name="vertexCount">Number of vertices in the mesh.</param>
        /// <param name="flexVertexLength">Length of the flex vertex array.</param>
        /// <returns>True if valid; otherwise false.</returns>
        private bool ValidateFlexData(mstudioflex_t flex, int vertexCount, int flexVertexLength)
        {
            if (flex.numVerts <= 0 || flex.numVerts > vertexCount)
            {
                Debug.LogWarning($"Flex data has an invalid number of vertices: {flex.numVerts}");
                return false;
            }

            if (flex.vertexOffset < 0 || flex.vertexOffset + flex.numVerts > flexVertexLength)
            {
                Debug.LogWarning($"Flex data has an invalid vertex offset: {flex.vertexOffset}");
                return false;
            }

            return true;
        }
    }

    public struct mstudioflexdesc_t
    {
        public int szFACSindex;

        /// <summary>
        /// Resolves the FACS name from MDL data.
        /// </summary>
        /// <param name="mdlData">The raw MDL data.</param>
        /// <param name="baseOffset">The base offset in the MDL file.</param>
        /// <returns>The FACS name as a string.</returns>
        public string pszFACS(byte[] mdlData, int baseOffset)
        {
            int offset = baseOffset + szFACSindex;

            if (offset < 0 || offset >= mdlData.Length)
            {
                Debug.LogError($"Invalid szFACSindex: {szFACSindex}");
                return string.Empty;
            }

            int length = 0;
            while (offset + length < mdlData.Length && mdlData[offset + length] != 0)
            {
                length++;
            }

            if (length == 0)
            {
                Debug.LogWarning("FACS name length is zero.");
                return string.Empty;
            }

            return Encoding.UTF8.GetString(mdlData, offset, length);
        }
    }
}
