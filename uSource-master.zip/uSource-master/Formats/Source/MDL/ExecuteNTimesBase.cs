﻿internal class ExecuteNTimesBase
{
}