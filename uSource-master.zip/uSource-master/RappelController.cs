﻿using UnityEngine;

public enum RappelState
{
    Idle,
    WaitingToRappel,
    Rappeling,
    OnGround
}

public class RappelController : MonoBehaviour
{
    public RappelState currentState = RappelState.Idle;

    private void Update()
    {
        switch (currentState)
        {
            case RappelState.WaitingToRappel:
                // Wait for the start signal
                break;
            case RappelState.Rappeling:
                // Perform rappelling logic
                break;
            case RappelState.OnGround:
                // Perform landing logic
                break;
        }
    }

    public void StartRappel(Vector3 target)
    {
        currentState = RappelState.Rappeling;
        // Begin the rappel process
    }
}
