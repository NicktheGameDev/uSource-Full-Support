using UnityEngine;

public class SourceEngineEyeMovement : MonoBehaviour
{
    [Header("Material Settings")]
    public Material leftEyeMaterial;  // Material for the left eye
    public Material rightEyeMaterial; // Material for the right eye

    [Header("Eye Movement Settings")]
    public Transform leftEyeTarget;   // Target for the left eye
    public Transform rightEyeTarget;  // Target for the right eye
    public Transform headPosition;    // Approximate head position (to simulate eye pivot)

    [Range(0.0f, 1.0f)]
    public float maxPupilOffset = 0.05f; // Maximum UV offset for pupil movement

    void Update()
    {
        if (headPosition == null || leftEyeMaterial == null || rightEyeMaterial == null)
        {
            Debug.LogWarning("Missing head position or eye materials!");
            return;
        }

        // Update eye materials with UV offsets
        if (leftEyeTarget != null)
        {
            Vector2 leftEyeOffset = CalculatePupilOffset(headPosition.position, leftEyeTarget.position);
            leftEyeMaterial.SetVector("_EyeCenter", leftEyeOffset);
        }

        if (rightEyeTarget != null)
        {
            Vector2 rightEyeOffset = CalculatePupilOffset(headPosition.position, rightEyeTarget.position);
            rightEyeMaterial.SetVector("_EyeCenter", rightEyeOffset);
        }
    }

    Vector2 CalculatePupilOffset(Vector3 headPosition, Vector3 targetPosition)
    {
        // Calculate direction from head to target
        Vector3 direction = (targetPosition - headPosition).normalized;

        // Map to UV space (x and y represent UV offsets)
        Vector2 uvOffset = new Vector2(direction.x, direction.y) * maxPupilOffset;

        // Clamp to ensure it stays within the defined range
        return Vector2.ClampMagnitude(uvOffset, maxPupilOffset);
    }
}
